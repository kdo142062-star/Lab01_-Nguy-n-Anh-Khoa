using System;

namespace Baitap01
{
    // Xây dựng lớp NhanVien
    class NhanVien
    {
        public string HoTen { get; set; } = string.Empty;
        public double MucLuong { get; set; }
        public int SoNgayVang { get; set; }

        // Phương thức nhập thông tin nhân viên
        public void NhapThongTin()
        {
            Console.Write("Nhap ho ten nhan vien: ");
            HoTen = Console.ReadLine() ?? "";

            // Nhập mức lương: Hỗ trợ cả số liền (10000000) lẫn có dấu chấm/phẩy (10.000.000)
            Console.Write("Nhap muc luong (vi du: 10000000 hoặc 10.000.000): ");
            double luong;
            while (true)
            {
                string input = Console.ReadLine() ?? "";
                // Loại bỏ tất cả dấu chấm (.) và dấu phẩy (,) phân cách hàng nghìn
                string cleanInput = input.Replace(".", "").Replace(",", "").Trim();

                if (double.TryParse(cleanInput, out luong) && luong >= 0)
                {
                    break;
                }
                Console.Write("Gia tri khong hop le. Vui lòng nhập lại mức lương: ");
            }
            MucLuong = luong;

            // Nhập số ngày vắng
            Console.Write("Nhap so ngay vang: ");
            int vang;
            while (true)
            {
                string input = Console.ReadLine() ?? "";
                string cleanInput = input.Replace(".", "").Replace(",", "").Trim();

                if (int.TryParse(cleanInput, out vang) && vang >= 0)
                {
                    break;
                }
                Console.Write("Gia tri khong hop le. Vui lòng nhập lại số ngày vắng: ");
            }
            SoNgayVang = vang;
        }

        // Phương thức tính lương thực lĩnh (trừ 100.000 VNĐ cho mỗi ngày vắng)
        public double TinhThucLanh()
        {
            double thucLanh = MucLuong - (SoNgayVang * 100000);
            return thucLanh > 0 ? thucLanh : 0; // Đảm bảo lương không bị âm
        }

        // Phương thức xuất thông tin và tiền lương
        public void XuatThongTin()
        {
            Console.WriteLine("\n--- THONG TIN LUONG NHAN VIEN ---");
            Console.WriteLine($"Họ tên nhân viên : {HoTen}");
            Console.WriteLine($"Mức lương ban đầu: {MucLuong:N0} VNĐ");
            Console.WriteLine($"Số ngày vắng     : {SoNgayVang}");
            Console.WriteLine($"Lương thực lĩnh  : {TinhThucLanh():N0} VNĐ");
        }
    }

    class Bai14
    {
        public static void ChayBai14()
        {
            Console.WriteLine("=== TINH LUONG NHAN VIEN (BAI 14) ===");
            
            // Khởi tạo đối tượng NhanVien
            NhanVien nv = new NhanVien();

            // Gọi các phương thức nhập, tính và xuất
            nv.NhapThongTin();
            nv.XuatThongTin();
        }
    }
}