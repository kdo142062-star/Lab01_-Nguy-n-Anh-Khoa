using System;
using System.Drawing;
using System.Windows.Forms;

namespace MayTinhBoTui
{
    public partial class frmMenu : Form
    {
        private Button? btnMayTinh;
        private Button? btnKhachSan;
        private Label? lblTieuDe;

        public frmMenu()
        {
            // Đã xóa InitializeComponent() ở đây
            KhoiTaoGiaoDienMenu();
        }

        private void KhoiTaoGiaoDienMenu()
        {
            this.Text = "Chọn Bài Tập";
            this.Size = new Size(350, 250);
            this.StartPosition = FormStartPosition.CenterScreen;

            lblTieuDe = new Label();
            lblTieuDe.Text = "CHỌN CHƯƠNG TRÌNH THỰC THI";
            lblTieuDe.Font = new Font("Arial", 12, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.Navy;
            lblTieuDe.Location = new Point(45, 25);
            lblTieuDe.AutoSize = true;
            this.Controls.Add(lblTieuDe);

            btnMayTinh = new Button();
            btnMayTinh.Text = "1. Máy Tính Bỏ Túi";
            btnMayTinh.Font = new Font("Arial", 10, FontStyle.Bold);
            btnMayTinh.Location = new Point(60, 75);
            btnMayTinh.Size = new Size(210, 40);
            btnMayTinh.Click += (s, e) => {
                this.Hide();
                frmMayTinhBoTui frm = new frmMayTinhBoTui();
                frm.ShowDialog();
                this.Show();
            };
            this.Controls.Add(btnMayTinh);

            btnKhachSan = new Button();
            btnKhachSan.Text = "2. Quản Lý Khách Sạn";
            btnKhachSan.Font = new Font("Arial", 10, FontStyle.Bold);
            btnKhachSan.Location = new Point(60, 130);
            btnKhachSan.Size = new Size(210, 40);
            btnKhachSan.Click += (s, e) => {
                this.Hide();
                frmDangkyKS frm = new frmDangkyKS();
                frm.ShowDialog();
                this.Show();
            };
            this.Controls.Add(btnKhachSan);
        }
    }
}