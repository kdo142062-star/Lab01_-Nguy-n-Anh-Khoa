using System;
using System.Globalization;

namespace QuanLyKeThuaDaHinh
{
    // Lớp SanPham dùng để kiểm thử việc sắp xếp tổng quát qua Delegate
    public class SanPham
    {
        private string maSP;
        private string tenSP;
        private double gia;

        public SanPham()
        {
            maSP = "";
            tenSP = "";
            gia = 0;
        }

        public SanPham(string maSP, string tenSP, double gia)
        {
            this.maSP = maSP;
            this.tenSP = tenSP;
            this.gia = gia;
        }

        public string MaSP => maSP;
        public string TenSP => tenSP;
        public double Gia => gia;

        public void Input()
        {
            Console.Write("  - Nhập mã sản phẩm: ");
            maSP = Console.ReadLine();

            Console.Write("  - Nhập tên sản phẩm: ");
            tenSP = Console.ReadLine();

            while (true)
            {
                Console.Write("  - Nhập giá sản phẩm (VD: 1500000 hoặc 1,500,000): ");
                string strGia = Console.ReadLine();
                string cleanInput = strGia.Trim().Replace(".", "").Replace(",", "").Replace(" ", "");

                if (double.TryParse(cleanInput, NumberStyles.Any, CultureInfo.InvariantCulture, out gia) && gia >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Giá sản phẩm không hợp lệ! Vui lòng nhập lại.");
            }
        }

        public override string ToString()
        {
            return $"Mã SP: {maSP,-10} | Tên SP: {tenSP,-20} | Giá: {gia,12:N0} VNĐ";
        }
    }

    // Lớp chứa phương thức tĩnh tổng quát sắp xếp mảng sử dụng Delegate (Comparison<T>)
    public static class DelegateSorter
    {
        // Phương thức MySort sử dụng Delegate kiểu Comparison<T> (nhận vào 2 đối tượng và trả về int)
        public static void MySort<T>(T[] array, Comparison<T> comparison)
        {
            if (array == null || array.Length <= 1 || comparison == null) return;

            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    // Gọi delegate comparison để so sánh 2 phần tử
                    // Nếu phần tử trước lớn hơn phần tử sau (> 0) thì đổi chỗ
                    if (comparison(array[j], array[j + 1]) > 0)
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }
    }

    // Lớp quản lý danh sách sản phẩm kiểm thử Bài 3.3
    public class QuanLySortDelegate
    {
        private SanPham[] danhSachSP;

        public QuanLySortDelegate()
        {
            danhSachSP = new SanPham[0];
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH SẢN PHẨM ---");
            while (true)
            {
                Console.Write("Nhập số lượng sản phẩm n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    danhSachSP = new SanPham[n];
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập sản phẩm thứ {i + 1}:");
                        danhSachSP[i] = new SanPham();
                        danhSachSP[i].Input();
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSachSP == null || danhSachSP.Length == 0)
            {
                Console.WriteLine("Danh sách sản phẩm trống!");
                return;
            }

            foreach (var sp in danhSachSP)
            {
                Console.WriteLine(sp);
            }
        }

        // Sắp xếp tăng dần theo Giá sử dụng Delegate (Anonymous method / Lambda expression)
        public void SapXepTheoGiaTangDan()
        {
            DelegateSorter.MySort(danhSachSP, (x, y) => x.Gia.CompareTo(y.Gia));
        }

        // Sắp xếp tăng dần theo Tên sản phẩm sử dụng Delegate
        public void SapXepTheoTenTangDan()
        {
            DelegateSorter.MySort(danhSachSP, (x, y) => string.Compare(x.TenSP, y.TenSP, StringComparison.OrdinalIgnoreCase));
        }
    }
}