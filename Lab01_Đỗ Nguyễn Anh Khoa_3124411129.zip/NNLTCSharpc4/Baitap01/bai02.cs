using System;

namespace Baitap01
{
    class Bai02
    {
        public static void ChayBai2()
        {
            // Bài 2: Nhập họ tên và xuất ra theo định dạng
            Console.Write("Nhap ho ten cua ban: ");
            string hoTen = Console.ReadLine().Trim();

            // Tách họ tên để in định dạng theo mẫu:
            // Ví dụ: Nguyen Van An -> Chao ban Nguyen Van \n An!
            int lastSpaceIndex = hoTen.LastIndexOf(' ');
            if (lastSpaceIndex != -1)
            {
                string hoVaDem = hoTen.Substring(0, lastSpaceIndex);
                string ten = hoTen.Substring(lastSpaceIndex + 1);

                Console.WriteLine($"Chao ban {hoVaDem}");
                Console.WriteLine($"{ten}!");
            }
            else
            {
                Console.WriteLine("Chao ban");
                Console.WriteLine($"{hoTen}!");
            }
        }
    }
}