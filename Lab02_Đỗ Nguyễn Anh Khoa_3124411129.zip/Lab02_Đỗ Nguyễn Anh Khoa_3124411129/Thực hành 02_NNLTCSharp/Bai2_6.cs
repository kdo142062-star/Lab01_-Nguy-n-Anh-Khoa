using System;
using System.Collections.Generic;
using QuanLyPhanSo;

namespace QuanLyDayPhanSo
{
    public class ListPhanSo
    {
        // 1. Field: Danh sách lưu trữ các phân số
        private List<PhanSo> danhSach;

        // 2. Constructors
        public ListPhanSo()
        {
            danhSach = new List<PhanSo>();
        }

        public ListPhanSo(int n)
        {
            danhSach = new List<PhanSo>();
            for (int i = 0; i < n; i++)
            {
                danhSach.Add(new PhanSo(0, 1));
            }
        }

        public ListPhanSo(ListPhanSo other)
        {
            danhSach = new List<PhanSo>();
            if (other != null && other.danhSach != null)
            {
                foreach (var ps in other.danhSach)
                {
                    danhSach.Add(new PhanSo(ps.TuSo, ps.MauSo));
                }
            }
        }

        // Thuộc tính lấy số lượng phần tử
        public int Count
        {
            get { return danhSach.Count; }
        }

        // 3. Indexer để truy cập phân số thứ i trong dãy
        public PhanSo this[int index]
        {
            get
            {
                if (index >= 0 && index < danhSach.Count)
                {
                    return danhSach[index];
                }
                throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn của dãy phân số!");
            }
            set
            {
                if (index >= 0 && index < danhSach.Count && value != null)
                {
                    danhSach[index] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException("Chỉ số (index) không hợp lệ hoặc phân số null!");
                }
            }
        }

        // 4. Methods nghiệp vụ
        public void Input()
        {
            Console.WriteLine("--- NHẬP DÃY PHÂN SỐ ---");
            while (true)
            {
                Console.Write("Nhập số lượng phân số n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    danhSach.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập phân số thứ {i + 1}:");
                        PhanSo ps = new PhanSo();
                        ps.Input($"thứ {i + 1}");
                        danhSach.Add(ps);
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSach == null || danhSach.Count == 0)
            {
                Console.WriteLine("Dãy phân số đang trống!");
                return;
            }

            for (int i = 0; i < danhSach.Count; i++)
            {
                Console.Write($"PS[{i + 1}] = {danhSach[i]}   ");
            }
            Console.WriteLine();
        }

        // Tính tổng của n phân số trong dãy (Khắc phục lỗi thiếu hàm RutGon bằng cách bỏ gọi RutGon trực tiếp nếu lớp PhanSo không hỗ trợ)
        public PhanSo TinhTong()
        {
            PhanSo tong = new PhanSo(0, 1);
            
            foreach (var ps in danhSach)
            {
                tong = tong + ps;
            }
            
            return tong;
        }
    }
}