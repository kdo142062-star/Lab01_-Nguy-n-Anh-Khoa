using System;

namespace QuanLyHinhHoc
{
    public class Point
    {
        // 1. Fields (Trường dữ liệu tọa độ x, y)
        private double x;
        private double y;

        // 2. Constructors (Hàm khởi tạo)
        // Default constructor khởi tạo giá trị ban đầu cho x và y bằng 0
        public Point()
        {
            x = 0;
            y = 0;
        }

        // Constructor có tham số
        public Point(double x, double y)
        {
            X = x;
            Y = y;
        }

        // 3. Properties (Thuộc tính đóng gói dữ liệu)
        public double X
        {
            get { return x; }
            set { x = value; }
        }

        public double Y
        {
            get { return y; }
            set { y = value; }
        }

        // 4. Methods (Phương thức nhập, xuất và override ToString)
        public void Input(string tenDiem)
        {
            Console.WriteLine($"--- Nhập tọa độ cho điểm {tenDiem} ---");
            
            // Nhập hoành độ X có chống lỗi
            while (true)
            {
                Console.Write($"Nhập tọa độ X cho {tenDiem}: ");
                string inputX = Console.ReadLine();
                if (double.TryParse(inputX, out double valX))
                {
                    X = valX;
                    break;
                }
                Console.WriteLine("[Lỗi] Giá trị không hợp lệ! Vui lòng nhập vào một số thực.");
            }

            // Nhập tung độ Y có chống lỗi
            while (true)
            {
                Console.Write($"Nhập tọa độ Y cho {tenDiem}: ");
                string inputY = Console.ReadLine();
                if (double.TryParse(inputY, out double valY))
                {
                    Y = valY;
                    break;
                }
                Console.WriteLine("[Lỗi] Giá trị không hợp lệ! Vui lòng nhập vào một số thực.");
            }
        }

        public void Output()
        {
            Console.WriteLine($"({X}, {Y})");
        }

        // Override hàm ToString() để xuất Point
        public override string ToString()
        {
            return $"({X}, {Y})";
        }

        // 5. Phép toán (Operator Overloading): +, -, lấy âm (-)
        public static Point operator +(Point p1, Point p2)
        {
            return new Point(p1.X + p2.X, p1.Y + p2.Y);
        }

        public static Point operator -(Point p1, Point p2)
        {
            return new Point(p1.X - p2.X, p1.Y - p2.Y);
        }

        public static Point operator -(Point p)
        {
            return new Point(-p.X, -p.Y);
        }

        // =========================================================================
        // (a) KHOẢNG CÁCH GIỮA 2 ĐIỂM (2 cách: Phương thức thành viên & Tĩnh)
        // =========================================================================
        public double TinhKhoangCach(Point pKhac)
        {
            return Math.Sqrt(Math.Pow(pKhac.X - this.X, 2) + Math.Pow(pKhac.Y - this.Y, 2));
        }

        public static double TinhKhoangCach(Point p1, Point p2)
        {
            return Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));
        }

        // =========================================================================
        // (b) TRUNG ĐIỂM CỦA 2 ĐIỂM (2 cách: Phương thức thành viên & Tĩnh)
        // =========================================================================
        public Point TimTrungDiem(Point pKhac)
        {
            double xMid = (this.X + pKhac.X) / 2.0;
            double yMid = (this.Y + pKhac.Y) / 2.0;
            return new Point(xMid, yMid);
        }

        public static Point TimTrungDiem(Point p1, Point p2)
        {
            double xMid = (p1.X + p2.X) / 2.0;
            double yMid = (p1.Y + p2.Y) / 2.0;
            return new Point(xMid, yMid);
        }
    }
}