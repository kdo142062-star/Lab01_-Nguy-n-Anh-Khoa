using System;
using System.Collections.Generic;

namespace Baitap01
{
    // Xây dựng lớp xử lý mảng 2 chiều
    class MangHaiChieu
    {
        private int[,] maTrân = new int[0, 0];

        // 1. Phương thức sinh ngẫu nhiên mảng A[nxm] trong đoạn [10, 100]
        public void SinhNgauNhien()
        {
            Console.Write("Nhập số dòng n: ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Giá trị không hợp lệ. Vui lòng nhập lại n (> 0): ");
            }

            Console.Write("Nhập số cột m: ");
            int m;
            while (!int.TryParse(Console.ReadLine(), out m) || m <= 0)
            {
                Console.Write("Giá trị không hợp lệ. Vui lòng nhập lại m (> 0): ");
            }

            maTrân = new int[n, m];
            Random rand = new Random();

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    // Sinh ngẫu nhiên trong đoạn [10, 100] (Next(10, 101) bao gồm 10 đến 100)
                    maTrân[i, j] = rand.Next(10, 101);
                }
            }
            Console.WriteLine($"Đã sinh ngẫu nhiên thành công mảng {n}x{m} trong đoạn [10, 100]!");
        }

        // 2. Phương thức in mảng ra màn hình dạng ma trận
        public void InMang()
        {
            int n = maTrân.GetLength(0);
            int m = maTrân.GetLength(1);

            if (n == 0 || m == 0)
            {
                Console.WriteLine("Mảng chưa được khởi tạo!");
                return;
            }

            Console.WriteLine("\n--- MA TRẬN A ---");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write($"{maTrân[i, j],5} "); // Căn lề đẹp mắt
                }
                Console.WriteLine();
            }
        }

        // 3. Phương thức trả về hai mảng: mảng các số chẵn và mảng các số lẻ
        public void TachChanLe(out int[] mangChan, out int[] mangLe)
        {
            List<int> chanList = new List<int>();
            List<int> leList = new List<int>();

            int n = maTrân.GetLength(0);
            int m = maTrân.GetLength(1);

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    int val = maTrân[i, j];
                    if (val % 2 == 0)
                    {
                        chanList.Add(val);
                    }
                    else
                    {
                        leList.Add(val);
                    }
                }
            }

            mangChan = chanList.ToArray();
            mangLe = leList.ToArray();
        }
    }

    class Bai17
    {
        public static void ChayBai17()
        {
            Console.WriteLine("=== XU LY MANG HAI CHIEU (BAI 17) ===");
            
            MangHaiChieu obj = new MangHaiChieu();

            // Sinh ngẫu nhiên mảng A[nxm]
            obj.SinhNgauNhien();

            // In mảng ra màn hình
            obj.InMang();

            // Tách mảng chẵn và lẻ
            obj.TachChanLe(out int[] chan, out int[] lẻ);

            Console.WriteLine("\n--- KẾT QUẢ TÁCH CHẴN / LẺ ---");
            Console.WriteLine($"Mảng các số chẵn ({chan.Length} số): " + (chan.Length > 0 ? string.Join(" ", chan) : "Không có"));
            Console.WriteLine($"Mảng các số lẻ ({lẻ.Length} số)  : " + (lẻ.Length > 0 ? string.Join(" ", lẻ) : "Không có"));
        }
    }
}