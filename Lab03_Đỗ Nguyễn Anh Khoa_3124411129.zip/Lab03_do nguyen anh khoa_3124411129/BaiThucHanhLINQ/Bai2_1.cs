using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

public class Bai2_1
{
    public static void ChayBai2_1()
    {
        Console.WriteLine("\n=== BÀI 2.1: TRUY VẤN MẢNG SỐ NGUYÊN ===");

        // Khai báo mảng số nguyên ban đầu theo đề bài
        int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };
        Console.WriteLine("Mảng ban đầu: " + string.Join(", ", mangSo));
        Console.WriteLine("--------------------------------------------------");

        // --- a. Liệt kê các phần tử chia hết cho 4 và 3 ---
        var kq_a_query = from n in mangSo
                         where n % 4 == 0 && n % 3 == 0
                         select n;
        var kq_a_method = mangSo.Where(n => n % 4 == 0 && n % 3 == 0);

        Console.WriteLine("a. Các phần tử chia hết cho 4 và 3:");
        Console.WriteLine($"   - Query Syntax : {string.Join(", ", kq_a_query)}");
        Console.WriteLine($"   - Method Syntax: {string.Join(", ", kq_a_method)}");

        // --- b. Liệt kê các phần tử nhỏ hơn hoặc bằng 3 ---
        var kq_b_query = from n in mangSo
                         where n <= 3
                         select n;
        var kq_b_method = mangSo.Where(n => n <= 3);

        Console.WriteLine("\nb. Các phần tử nhỏ hơn hoặc bằng 3:");
        Console.WriteLine($"   - Query Syntax : {string.Join(", ", kq_b_query)}");
        Console.WriteLine($"   - Method Syntax: {string.Join(", ", kq_b_method)}");

        // --- c. Tạo một dãy mới: số chẵn chia đôi, số lẻ giữ nguyên giá trị ---
        var kq_c_query = from n in mangSo
                         select n % 2 == 0 ? n / 2 : n;
        var kq_c_method = mangSo.Select(n => n % 2 == 0 ? n / 2 : n);

        Console.WriteLine("\nc. Dãy mới (chẵn chia đôi, lẻ giữ nguyên):");
        Console.WriteLine($"   - Query Syntax : {string.Join(", ", kq_c_query)}");
        Console.WriteLine($"   - Method Syntax: {string.Join(", ", kq_c_method)}");
        Console.WriteLine("--------------------------------------------------");
    }
}