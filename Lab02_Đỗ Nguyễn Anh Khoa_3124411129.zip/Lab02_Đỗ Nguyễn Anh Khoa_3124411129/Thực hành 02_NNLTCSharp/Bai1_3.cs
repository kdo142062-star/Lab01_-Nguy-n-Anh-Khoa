using System;

namespace QuanLyNhanSu
{
    public class Bai1_3
    {
        // 1. Fields (Dữ liệu thành viên)
        private string id;
        private string name;
        private int yob; // Năm sinh (Year of Birth)
        private int yod; // Năm mất (Year of Death - bằng 0 nếu còn sống)

        // 2. Constructors (Hàm khởi tạo)
        
        // a. Default Constructor
        public Bai1_3()
        {
            id = "001";
            name = "Chưa có tên";
            yob = 2000;
            yod = 0; // Mặc định là còn sống
        }

        // b. Parameterized Constructor
        public Bai1_3(string id, string name, int yob, int yod)
        {
            Id = id;
            Name = name;
            Yob = yob;
            Yod = yod;
        }

        // c. Copy Constructor
        public Bai1_3(Bai1_3 p)
        {
            if (p != null)
            {
                this.id = p.id;
                this.name = p.name;
                this.yob = p.yob;
                this.yod = p.yod;
            }
        }

        // 3. Properties (Thuộc tính đóng gói, kiểm tra dữ liệu an toàn)
        public string Id
        {
            get { return id; }
            set 
            { 
                // Kiểm tra xem ID có trống không và có phải là chuỗi số nguyên hợp lệ hay không
                if (!string.IsNullOrWhiteSpace(value) && int.TryParse(value.Trim(), out _))
                {
                    id = value.Trim();
                }
                else
                {
                    throw new ArgumentException("Mã ID không được để trống và phải là dãy ký tự số!");
                }
            }
        }

        public string Name
        {
            get { return name; }
            set 
            { 
                if (!string.IsNullOrWhiteSpace(value))
                    name = value.Trim();
                else
                    throw new ArgumentException("Họ tên không được để trống!");
            }
        }

        public int Yob
        {
            get { return yob; }
            set 
            { 
                int currentYear = DateTime.Now.Year;
                if (value >= 1800 && value <= currentYear)
                    yob = value;
                else
                    throw new ArgumentException($"Năm sinh phải nằm trong khoảng từ 1800 đến {currentYear}!");
            }
        }

        public int Yod
        {
            get { return yod; }
            set 
            { 
                int currentYear = DateTime.Now.Year;
                if (value == 0 || (value >= yob && value <= currentYear))
                    yod = value;
                else
                    throw new ArgumentException($"Năm mất phải bằng 0 (nếu còn sống) hoặc từ {yob} đến {currentYear}!");
            }
        }

        // 4. Methods (Phương thức nghiệp vụ)

        // Phương thức IsLiving(): Trả về false hay true tùy thuộc vào yod bằng 0 hay khác 0
        public bool IsLiving()
        {
            return yod == 0;
        }

        // Phương thức Input(): Nhập dữ liệu có cơ chế chống lỗi, nếu nhập ID bằng chữ sẽ bắt nhập lại ngay
        public void Input()
        {
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("           NHẬP THÔNG TIN CÁ NHÂN                 ");
            Console.WriteLine("--------------------------------------------------");

            // Nhập ID (bắt buộc phải là dạng số, nếu nhập chữ sẽ báo lỗi và cho nhập lại)
            while (true)
            {
                try
                {
                    Console.Write("Nhập mã định danh ID (ví dụ 123): ");
                    string inputId = Console.ReadLine();
                    Id = inputId; // Nếu là chữ, Property sẽ quăng lỗi để bắt lại
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }

            // Nhập Họ tên
            while (true)
            {
                try
                {
                    Console.Write("Nhập họ tên: ");
                    Name = Console.ReadLine();
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }

            // Nhập Năm sinh (Yob)
            while (true)
            {
                try
                {
                    Console.Write("Nhập năm sinh (ví dụ 1995): ");
                    if (int.TryParse(Console.ReadLine(), out int year))
                    {
                        Yob = year;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập số nguyên.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }

            // Nhập Năm mất (Yod)
            while (true)
            {
                try
                {
                    Console.Write("Nhập năm mất (Nhập 0 nếu vẫn còn sống): ");
                    if (int.TryParse(Console.ReadLine(), out int deathYear))
                    {
                        Yod = deathYear;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập số nguyên.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }
        }

        // Phương thức Output(): Xuất thông tin
        public void Output()
        {
            Console.WriteLine($"-> Mã ID      : {Id}");
            Console.WriteLine($"-> Họ tên     : {Name}");
            Console.WriteLine($"-> Năm sinh   : {Yob}");
            Console.WriteLine($"-> Năm mất    : {(Yod == 0 ? "Chưa có (Còn sống)" : Yod.ToString())}");
            Console.WriteLine($"-> Trạng thái : {(IsLiving() ? "Đang sống (True)" : "Đã mất (False)")}");
        }
    }
}