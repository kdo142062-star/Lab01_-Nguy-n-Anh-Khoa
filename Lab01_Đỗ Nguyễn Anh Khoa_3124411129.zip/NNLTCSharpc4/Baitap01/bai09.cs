using System;

namespace Baitap01
{
    class Bai09
    {
        // Phương thức sử dụng out để trả về cả max và min của 3 số thực
        public static void TimMaxMin(double a, double b, double c, out double max, out double min)
        {
            max = a;
            min = a;

            // Tìm Max
            if (b > max) max = b;
            if (c > max) max = c;

            // Tìm Min
            if (b < min) min = b;
            if (c < min) min = c;
        }

        public static void ChayBai9()
        {
            Console.WriteLine("=== TIM MAX VA MIN VOI OUT (BAI 9) ===");
            
            Console.Write("Nhap so thu nhat (a): ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thu hai (b): ");
            double b = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thu ba (c): ");
            double c = double.Parse(Console.ReadLine());

            // Khai báo biến nhận giá trị từ out (không cần khởi tạo trước giá trị)
            double soLonNhat, soNhoNhat;

            // Gọi phương thức
            TimMaxMin(a, b, c, out soLonNhat, out soNhoNhat);

            Console.WriteLine($"\nBa so da nhap: a = {a}, b = {b}, c = {c}");
            Console.WriteLine($"Gia tri LON NHAT la: {soLonNhat}");
            Console.WriteLine($"Gia tri NHO NHAT la: {soNhoNhat}");
        }
    }
}