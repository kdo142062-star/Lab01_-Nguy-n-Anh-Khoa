using System;
using System.Collections;
using QuanLyHinhHoc; 

namespace QuanLyHinhHoc
{
    public class ArrayPoint
    {
        // 1. Field: Một ArrayList lưu trữ các đối tượng Point
        private ArrayList listPoints;

        // 2. Constructors (Hàm khởi tạo)
        public ArrayPoint()
        {
            listPoints = new ArrayList();
        }

        public ArrayPoint(ArrayList list)
        {
            listPoints = list != null ? new ArrayList(list) : new ArrayList();
        }

        // 3. Indexer cho phép truy cập Point thứ i của ArrayList giống như mảng thông thường
        public Point this[int index]
        {
            get
            {
                if (index >= 0 && index < listPoints.Count)
                {
                    return (Point)listPoints[index]; // Ép kiểu từ object sang Point
                }
                throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn của mảng điểm!");
            }
            set
            {
                if (index >= 0 && index < listPoints.Count)
                {
                    listPoints[index] = value;
                }
                else if (index == listPoints.Count)
                {
                    listPoints.Add(value);
                }
                else
                {
                    throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn của mảng điểm!");
                }
            }
        }

        // Thuộc tính lấy số lượng phần tử
        public int Count
        {
            get { return listPoints.Count; }
        }

        // 4. Methods nghiệp vụ (Nhập, Xuất, Thêm)
        public void Add(Point p)
        {
            if (p != null)
            {
                listPoints.Add(p);
            }
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH ĐIỂM (ArrayPoint) ---");
            while (true)
            {
                Console.Write("Nhập số lượng điểm n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    listPoints.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập tọa độ cho điểm thứ {i}:");
                        Point p = new Point();
                        p.Input($"[{i}]");
                        listPoints.Add(p);
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (listPoints.Count == 0)
            {
                Console.WriteLine("Danh sách điểm đang trống!");
                return;
            }

            Console.WriteLine("Danh sách các điểm trong ArrayPoint:");
            for (int i = 0; i < listPoints.Count; i++)
            {
                // Sử dụng trực tiếp Indexer thông qua cú pháp arr[i]
                Console.WriteLine($"  Point [{i}] = {this[i]}");
            }
        }
    }
}