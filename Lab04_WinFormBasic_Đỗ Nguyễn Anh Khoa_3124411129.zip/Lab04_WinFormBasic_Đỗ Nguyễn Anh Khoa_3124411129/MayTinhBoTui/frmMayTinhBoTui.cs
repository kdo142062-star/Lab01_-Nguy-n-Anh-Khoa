using System;
using System.Drawing;
using System.Windows.Forms;

namespace MayTinhBoTui
{
    public partial class frmMayTinhBoTui : Form
    {
        private TextBox txtHienThi;
        private Label lblTieuDe;
        
        private double so1 = 0;
        private double so2 = 0;
        private string phepToan = "";
        private bool nhapSoMoi = true;

        public frmMayTinhBoTui()
        {
            InitializeComponent();

            this.Text = "Máy Tính Bỏ Túi";
            this.Size = new Size(310, 390);
            this.StartPosition = FormStartPosition.CenterScreen;

            KhoiTaoGiaoDien();
        }

        private void KhoiTaoGiaoDien()
        {
            lblTieuDe = new Label();
            lblTieuDe.Text = "Máy Tính Bỏ Túi";
            lblTieuDe.Font = new Font("Arial", 16, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.Red;
            lblTieuDe.Location = new Point(50, 15);
            lblTieuDe.AutoSize = true;
            this.Controls.Add(lblTieuDe);

            txtHienThi = new TextBox();
            txtHienThi.Location = new Point(20, 55);
            txtHienThi.Size = new Size(255, 30);
            txtHienThi.Font = new Font("Arial", 14, FontStyle.Regular);
            txtHienThi.ForeColor = Color.Blue;
            txtHienThi.TextAlign = HorizontalAlignment.Right;
            txtHienThi.ReadOnly = true;
            txtHienThi.Text = "0";
            this.Controls.Add(txtHienThi);

            string[] danhSachNut = {
                "1", "2", "3", "4",
                "5", "6", "7", "8",
                "9", "0", "=", "C",
                "+", "-", "*", "/"
            };

            int startX = 20;
            int startY = 100;
            int width = 58;
            int height = 45;
            int gap = 7;

            for (int i = 0; i < danhSachNut.Length; i++)
            {
                string text = danhSachNut[i];
                int col = i % 4;
                int row = i / 4;

                int x = startX + col * (width + gap);
                int y = startY + row * (height + gap);

                Button btn = TaoButton(text, x, y, width, height, Color.WhiteSmoke);

                // Kiểm tra nếu là ký tự số từ 0 đến 9
                if (char.IsDigit(text[0]))
                {
                    btn.Click += So_Click;
                }
                else if (text == "+" || text == "-" || text == "*" || text == "/")
                {
                    btn.Click += PhepToan_Click;
                }
                else if (text == "=")
                {
                    btn.Click += BtnBang_Click;
                }
                else if (text == "C")
                {
                    btn.Click += BtnXoa_Click;
                }
            }
        }

        private Button TaoButton(string text, int left, int top, int width, int height, Color color)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Left = left;
            btn.Top = top;
            btn.Width = width;
            btn.Height = height;
            btn.BackColor = color;
            btn.Font = new Font("Arial", 12, FontStyle.Bold);
            this.Controls.Add(btn);
            return btn;
        }

        private void So_Click(object? sender, EventArgs e)
        {
            Button btn = (Button)sender!;
            if (nhapSoMoi)
            {
                txtHienThi.Text = btn.Text;
                nhapSoMoi = false;
            }
            else
            {
                if (txtHienThi.Text == "0")
                    txtHienThi.Text = btn.Text;
                else
                    txtHienThi.Text += btn.Text;
            }
        }

        private void PhepToan_Click(object? sender, EventArgs e)
        {
            Button btn = (Button)sender!;
            double.TryParse(txtHienThi.Text, out so1);
            phepToan = btn.Text;
            nhapSoMoi = true;
        }

        private void BtnBang_Click(object? sender, EventArgs e)
        {
            double.TryParse(txtHienThi.Text, out so2);
            double ketQua = 0;

            switch (phepToan)
            {
                case "+": ketQua = so1 + so2; break;
                case "-": ketQua = so1 - so2; break;
                case "*": ketQua = so1 * so2; break;
                case "/": 
                    if (so2 == 0)
                    {
                        MessageBox.Show("Không thể chia cho số 0!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    ketQua = so1 / so2; 
                    break;
            }

            txtHienThi.Text = ketQua.ToString();
            nhapSoMoi = true;
        }

        private void BtnXoa_Click(object? sender, EventArgs e)
        {
            txtHienThi.Text = "0";
            so1 = 0;
            so2 = 0;
            phepToan = "";
            nhapSoMoi = true;
        }
    }
}