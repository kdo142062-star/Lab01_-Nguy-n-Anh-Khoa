using System;
using System.Globalization;

namespace QuanLyKeThuaDaHinh
{
    // Định nghĩa Interface tổng quát tự chế để mô phỏng cơ chế so sánh
    public interface IMyComparable<T>
    {
        int CompareTo(T other);
    }

    // Lớp SinhVienSort áp dụng IMyComparable để kiểm chứng việc sắp xếp tổng quát
    public class SinhVienSort : IMyComparable<SinhVienSort>
    {
        private string maSV;
        private string hoTen;
        private double diemTB;

        public SinhVienSort()
        {
            maSV = "";
            hoTen = "";
            diemTB = 0;
        }

        public SinhVienSort(string maSV, string hoTen, double diemTB)
        {
            this.maSV = maSV;
            this.hoTen = hoTen;
            this.diemTB = diemTB;
        }

        public void Input()
        {
            Console.Write("  - Nhập mã sinh viên: ");
            maSV = Console.ReadLine();

            Console.Write("  - Nhập họ tên sinh viên: ");
            hoTen = Console.ReadLine();

            while (true)
            {
                Console.Write("  - Nhập điểm trung bình (VD: 8.5): ");
                string strDiem = Console.ReadLine();
                if (double.TryParse(strDiem, NumberStyles.Any, CultureInfo.InvariantCulture, out diemTB) && diemTB >= 0 && diemTB <= 10)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Điểm không hợp lệ (từ 0 đến 10). Vui lòng nhập lại!");
            }
        }

        // Định nghĩa tiêu chí so sánh: Sắp xếp tăng dần theo Điểm trung bình
        public int CompareTo(SinhVienSort other)
        {
            if (other == null) return 1;
            return this.diemTB.CompareTo(other.diemTB);
        }

        public override string ToString()
        {
            return $"Mã SV: {maSV,-10} | Họ tên: {hoTen,-20} | Điểm TB: {diemTB,5:F2}";
        }
    }

    // Lớp chứa phương thức tĩnh tổng quát mô phỏng Array.Sort bằng Interface
    public static class UtilitySorter
    {
        // Phương thức MySort tổng quát nhận vào một mảng các kiểu T (với T phải thực thi IMyComparable<T>)
        public static void MySort<T>(T[] array) where T : IMyComparable<T>
        {
            if (array == null || array.Length <= 1) return;

            // Sử dụng thuật toán Bubble Sort hoặc Selection Sort đơn giản để sắp xếp dựa trên phương thức CompareTo từ Interface
            int n = array.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    // Nếu phần tử trước lớn hơn phần tử sau (CompareTo trả về > 0) thì đổi chỗ
                    if (array[j].CompareTo(array[j + 1]) > 0)
                    {
                        T temp = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = temp;
                    }
                }
            }
        }
    }

    // Lớp quản lý danh sách để kiểm thử Bài 3.2
    public class QuanLySortTongQuat
    {
        private SinhVienSort[] danhSachSV;

        public QuanLySortTongQuat()
        {
            danhSachSV = new SinhVienSort[0];
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH SINH VIÊN ---");
            while (true)
            {
                Console.Write("Nhập số lượng sinh viên n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    danhSachSV = new SinhVienSort[n];
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập sinh viên thứ {i + 1}:");
                        danhSachSV[i] = new SinhVienSort();
                        danhSachSV[i].Input();
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSachSV == null || danhSachSV.Length == 0)
            {
                Console.WriteLine("Danh sách trống!");
                return;
            }

            foreach (var sv in danhSachSV)
            {
                Console.WriteLine(sv);
            }
        }

        // Gọi phương thức tự chế MySort
        public void ThucHienSapXep()
        {
            UtilitySorter.MySort(danhSachSV);
        }
    }
}