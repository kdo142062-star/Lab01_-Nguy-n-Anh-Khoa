using System;

namespace QuanLyDaySo
{
    public class DaySo
    {
        // 1. Field: Mảng 1 chiều chứa các số nguyên
        private int[] arr;

        // 2. Constructors (Các loại Constructor)
        
        // Default constructor
        public DaySo()
        {
            arr = new int[0];
        }

        // Constructor có tham số kích thước
        public DaySo(int n)
        {
            if (n >= 0)
            {
                arr = new int[n];
            }
            else
            {
                arr = new int[0];
            }
        }

        // Copy constructor
        public DaySo(DaySo other)
        {
            if (other != null && other.arr != null)
            {
                arr = new int[other.arr.Length];
                Array.Copy(other.arr, arr, other.arr.Length);
            }
            else
            {
                arr = new int[0];
            }
        }

        // Thuộc tính lấy số lượng phần tử
        public int Length
        {
            get { return arr.Length; }
        }

        // 3. Indexer để truy cập phần tử thứ i trong dãy
        public int this[int index]
        {
            get
            {
                if (index >= 0 && index < arr.Length)
                {
                    return arr[index];
                }
                throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn của dãy số!");
            }
            set
            {
                if (index >= 0 && index < arr.Length)
                {
                    arr[index] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn của dãy số!");
                }
            }
        }

        // 4. Methods nghiệp vụ

        // Nhập dãy số
        public void Input()
        {
            Console.WriteLine("--- NHẬP DÃY SỐ NGUYÊN ---");
            while (true)
            {
                Console.Write("Nhập số lượng phần tử n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n >= 0)
                {
                    arr = new int[n];
                    for (int i = 0; i < n; i++)
                    {
                        while (true)
                        {
                            Console.Write($"Nhập phần tử thứ {i}: ");
                            if (int.TryParse(Console.ReadLine(), out int val))
                            {
                                arr[i] = val;
                                break;
                            }
                            Console.WriteLine("[Lỗi] Vui lòng nhập vào một số nguyên hợp lệ!");
                        }
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên không âm. Vui lòng nhập lại!");
            }
        }

        // Xuất dãy số
        public void Output()
        {
            if (arr == null || arr.Length == 0)
            {
                Console.WriteLine("Dãy số đang trống!");
                return;
            }
            Console.WriteLine(string.Join("  ", arr));
        }

        // Tìm và trả về một dãy số mới chỉ chứa các số chẵn
        public DaySo TimSoChan()
        {
            if (arr == null || arr.Length == 0) return new DaySo();

            // Đếm số lượng số chẵn trước để khởi tạo mảng vừa vặn
            int count = 0;
            foreach (var num in arr)
            {
                if (num % 2 == 0) count++;
            }

            DaySo chanList = new DaySo(count);
            int idx = 0;
            foreach (var num in arr)
            {
                if (num % 2 == 0)
                {
                    chanList[idx++] = num;
                }
            }
            return chanList;
        }
    }
}