using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Bai2_2
{
    public static void ChayBai2_2()
    {
        string[] mangChuoi = { "đầu", "lòng", "hai", "ả", "tố", "nga", "Thúy", "Kiều", "là", "chị", "em", "là", "Thúy", "Vân" };

        Console.WriteLine("=== BÀI 2.2: TRUY VẤN MẢNG CHUỖI ===");
        Console.WriteLine("Mảng ban đầu:");
        Console.WriteLine(string.Join(", ", mangChuoi));
        Console.WriteLine(new string('-', 40));

        // a. Liệt kê các phần tử có 4 ký tự và sắp xếp tăng dần theo ký tự đầu tiên
        Console.WriteLine("a. Các phần tử có 4 ký tự và sắp xếp tăng dần:");
        
        var kqQueryA = from s in mangChuoi
                       where s.Length == 4
                       orderby s
                       select s;
        Console.WriteLine("Query Syntax: " + string.Join(", ", kqQueryA));

        var kqMethodA = mangChuoi.Where(s => s.Length == 4).OrderBy(s => s);
        Console.WriteLine("Method Syntax: " + string.Join(", ", kqMethodA));
        Console.WriteLine();

        // b. Biến đổi mỗi phần tử thành dạng: <chữ thường> - <CHỮ HOA>
        Console.WriteLine("b. Biến đổi phần tử dạng <chữ thường> - <CHỮ HOA>:");
        
        var kqQueryB = from s in mangChuoi
                       select $"{s.ToLower()} - {s.ToUpper()}";
        Console.WriteLine("Query Syntax (kết quả mẫu): " + string.Join(" | ", kqQueryB));

        var kqMethodB = mangChuoi.Select(s => $"{s.ToLower()} - {s.ToUpper()}");
        Console.WriteLine("Method Syntax (kết quả mẫu): " + string.Join(" | ", kqMethodB));
        Console.WriteLine();

        // c. Liệt kê các phần tử có chứa ký tự "u" hoặc "U"
        Console.WriteLine("c. Các phần tử có chứa ký tự 'u':");
        
        var kqQueryC = from s in mangChuoi
                       where s.Contains("u") || s.Contains("U")
                       select s;
        Console.WriteLine("Query Syntax: " + string.Join(", ", kqQueryC));

        var kqMethodC = mangChuoi.Where(s => s.Contains("u") || s.Contains("U"));
        Console.WriteLine("Method Syntax: " + string.Join(", ", kqMethodC));
        Console.WriteLine();

        // d. Liệt kê các phần tử bắt đầu bằng chữ in hoa
        Console.WriteLine("d. Các phần tử bắt đầu bằng chữ in hoa:");
        
        var kqQueryD = from s in mangChuoi
                       where !string.IsNullOrEmpty(s) && char.IsUpper(s[0])
                       select s;
        Console.WriteLine("Query Syntax: " + string.Join(", ", kqQueryD));

        var kqMethodD = mangChuoi.Where(s => !string.IsNullOrEmpty(s) && char.IsUpper(s[0]));
        Console.WriteLine("Method Syntax: " + string.Join(", ", kqMethodD));
    }
}