﻿using System;

namespace BaiThucHanhLINQ;

class Program
{
    static void Main(string[] args)
    {
        // thiết lập hiển thị tiếng việt có dấu trên console
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        int chon;
        do
        {
            Console.Clear();
            Console.WriteLine("================ CHƯƠNG TRÌNH THỰC HÀNH LINQ ================");
            Console.WriteLine("1. Chạy Bài 2.1: Truy vấn mảng số nguyên");
            Console.WriteLine("2. Chạy Bài 2.2: Truy vấn mảng chuỗi");
            Console.WriteLine("3. Chạy Bài 3.1: Thống kê và phân nhóm mảng số");
            Console.WriteLine("4. Chạy Bài 3.2: Thống kê mảng chuỗi");
            Console.WriteLine("5. Chạy Bài 4.1: Nguồn dữ liệu đối tượng (MonHoc)");
            Console.WriteLine("6. Chạy Bài 5.1: Truy vấn cơ bản List<MonHoc>");
            Console.WriteLine("7. Chạy Bài 5.2: Thống kê nâng cao List<MonHoc>");
            Console.WriteLine("8. Chạy Bài 6.1: Nguồn dữ liệu Hệ (He)");
            Console.WriteLine("9. Chạy Bài 6.2: Join và các toán tử tập hợp");
            Console.WriteLine("0. Thoát chương trình");
            Console.WriteLine("==========================================================");
            Console.Write("Nhập lựa chọn của bạn: ");

            if (!int.TryParse(Console.ReadLine(), out chon))
            {
                Console.WriteLine("Lựa chọn không hợp lệ! Vui lòng nhập lại.");
                Console.ReadKey();
                continue;
            }

            switch (chon)
            {
                case 1:
                    Bai2_1.ChayBai2_1();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 2:
                    Bai2_2.ChayBai2_2();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 3:
                    Bai3_1.ChayBai3_1();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 4:
                    Bai3_2.ChayBai3_2();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 5:
                    Console.Clear();
                    Console.WriteLine("=== BÀI 4.1: XÂY DỰNG NGUỒN DỮ LIỆU ĐỐI TƯỢNG ===");
                    var dsMon = DuLieu.DS_Mon();
                    Console.WriteLine($"Đã tải thành công {dsMon.Count} môn học vào hệ thống:\n");
                    foreach (var mh in dsMon)
                    {
                        Console.WriteLine($"- [{mh.MaMon}] {mh.TenMon} (Hệ: {mh.He}, Số tiết: {mh.SoTiet})");
                    }
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 6:
                    Bai5_1.ChayBai5_1();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 7:
                    Bai5_2.ChayBai5_2();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 8:
                    Bai6_1.ChayBai6_1();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 9:
                    Bai6_2.ChayBai6_2();
                    Console.WriteLine("\nNhấn phím bất kỳ để quay lại menu...");
                    Console.ReadKey();
                    break;
                case 0:
                    Console.WriteLine("\nCảm ơn bạn đã sử dụng chương trình!");
                    break;
                default:
                    Console.WriteLine("\nLựa chọn không tồn tại. Vui lòng chọn lại!");
                    Console.ReadKey();
                    break;
            }

        } while (chon != 0);
    }
}