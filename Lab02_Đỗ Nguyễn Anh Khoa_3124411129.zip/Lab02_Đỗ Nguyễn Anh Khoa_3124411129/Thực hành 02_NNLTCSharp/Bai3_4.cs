using System;
using System.Globalization;

namespace QuanLyKeThuaDaHinh
{
    public class MenuEventArgs : EventArgs
    {
        public int Choice { get; }
        public MenuEventArgs(int choice)
        {
            Choice = choice;
        }
    }

    public class ConsoleMenu
    {
        public delegate void MenuChoiceHandler(object sender, MenuEventArgs e);
        public event MenuChoiceHandler Choose;

        protected string Title { get; set; }
        protected string[] Options { get; set; }

        public ConsoleMenu(string title, string[] options)
        {
            Title = title;
            Options = options;
        }

        public virtual void Run()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("==================================================");
                Console.WriteLine($"        {Title}       ");
                Console.WriteLine("==================================================");
                
                for (int i = 0; i < Options.Length; i++)
                {
                    Console.WriteLine($" {i + 1}. {Options[i]}");
                }
                Console.WriteLine(" 0. Thoát chương trình");
                Console.WriteLine("==================================================");
                Console.Write("Thực hiện: ");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    if (choice == 0)
                    {
                        Console.WriteLine("Cảm ơn bạn đã sử dụng chương trình. Tạm biệt!");
                        break;
                    }

                    OnChoose(new MenuEventArgs(choice));
                }
                else
                {
                    Console.WriteLine("[Lỗi] Lựa chọn không hợp lệ! Vui lòng nhập số.");
                }

                Console.WriteLine("\n--------------------------------------------------");
                Console.Write("Nhấn phím bất kỳ để tiếp tục...");
                Console.ReadKey();
            }
        }

        protected virtual void OnChoose(MenuEventArgs e)
        {
            Choose?.Invoke(this, e);
        }
    }

    public class PTBac2Console : ConsoleMenu
    {
        private double a, b, c;
        private string ketQuaGiai; // Biến lưu trữ kết quả giải phương trình

        public PTBac2Console() : base("GIẢI PHƯƠNG TRÌNH BẬC HAI (ax^2 + bx + c = 0)", 
            new string[] { "Nhập hệ số a, b, c", "Giải phương trình", "Xem lại hệ số và kết quả" })
        {
            a = 0; b = 0; c = 0;
            ketQuaGiai = "Chưa giải phương trình.";
            
            this.Choose += PTBac2Console_Choose;
        }

        private void PTBac2Console_Choose(object sender, MenuEventArgs e)
        {
            Console.WriteLine($"\nBạn thực hiện chức năng {e.Choice}:");
            switch (e.Choice)
            {
                case 1:
                    NhapHeSo();
                    break;
                case 2:
                    GiaiPhuongTrinh();
                    break;
                case 3:
                    XemThongTin();
                    break;
                default:
                    Console.WriteLine("[Lỗi] Chức năng không tồn tại trong hệ thống!");
                    break;
            }
        }

        private void NhapHeSo()
        {
            Console.WriteLine("--- NHẬP HỆ SỐ PHƯƠNG TRÌNH ---");
            a = DocSoThuc("Nhập a: ");
            b = DocSoThuc("Nhập b: ");
            c = DocSoThuc("Nhập c: ");
            ketQuaGiai = "Chưa giải phương trình (Đã thay đổi hệ số mới).";
            Console.WriteLine("-> Đã cập nhật hệ số thành công!");
        }

        private double DocSoThuc(string message)
        {
            double result;
            while (true)
            {
                Console.Write(message);
                string input = Console.ReadLine();
                if (double.TryParse(input, NumberStyles.Any, CultureInfo.InvariantCulture, out result))
                {
                    return result;
                }
                Console.WriteLine("[Lỗi] Giá trị không hợp lệ. Vui lòng nhập lại số thực!");
            }
        }

        private void GiaiPhuongTrinh()
        {
            Console.WriteLine($"--- GIẢI PHƯƠNG TRÌNH: {a}x^2 + {b}x + {c} = 0 ---");
            if (a == 0)
            {
                if (b == 0)
                {
                    if (c == 0)
                        ketQuaGiai = "Phương trình có vô số nghiệm.";
                    else
                        ketQuaGiai = "Phương trình vô nghiệm.";
                }
                else
                {
                    double x = -c / b;
                    ketQuaGiai = $"Phương trình có 1 nghiệm bậc nhất: x = {x:F4}";
                }
            }
            else
            {
                double delta = b * b - 4 * a * c;
                Console.WriteLine($"Delta = {delta:F4}");
                if (delta < 0)
                {
                    ketQuaGiai = "Phương trình vô nghiệm thực (Delta < 0).";
                }
                else if (delta == 0)
                {
                    double x = -b / (2 * a);
                    ketQuaGiai = $"Phương trình có nghiệm kép: x1 = x2 = {x:F4}";
                }
                else
                {
                    double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                    double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                    ketQuaGiai = $"Phương trình có 2 nghiệm phân biệt:\n  + x1 = {x1:F4}\n  + x2 = {x2:F4}";
                }
            }
            Console.WriteLine(ketQuaGiai);
        }

        private void XemThongTin()
        {
            Console.WriteLine("--- XEM LẠI THÔNG TIN & KẾT QUẢ ---");
            Console.WriteLine($" Phương trình hiện tại: {a}x^2 + {b}x + {c} = 0");
            Console.WriteLine($" Kết quả gần nhất: \n{ketQuaGiai}");
        }
    }
}