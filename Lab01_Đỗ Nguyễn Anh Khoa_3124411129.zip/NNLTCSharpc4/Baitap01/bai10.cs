using System;
using System.Text;

namespace Baitap01
{
    class Bai10
    {
        // Phương thức kiểm tra chuỗi đối xứng
        public static bool KiemTraDoiXung(string s)
        {
            if (string.IsNullOrEmpty(s)) return true;

            // Xóa khoảng trắng và chuyển về chữ thường (nếu muốn kiểm tra chuẩn đối xứng ký tự)
            s = s.Replace(" ", "").ToLower();

            int left = 0;
            int right = s.Length - 1;

            while (left < right)
            {
                if (s[left] != s[right])
                {
                    return false;
                }
                left++;
                right--;
            }
            return true;
        }

        public static void ChayBai10()
        {
            Console.WriteLine("=== KIEM TRA CHUOI DOI XUNG (BAI 10) ===");
            
            Console.Write("Nhap vao mot chuoi bat ky: ");
            string input = Console.ReadLine();

            if (KiemTraDoiXung(input))
            {
                Console.WriteLine($"Chuoi \"{input}\" LA chuoi doi xứng.");
            }
            else
            {
                Console.WriteLine($"Chuoi \"{input}\" KHONG PHAI la chuoi doi xứng.");
            }
        }
    }
}