﻿using System;

// Khai báo đầy đủ các namespace của tất cả các bài tập trong dự án
using QuanLySinhVien;
using QuanLyHinhHoc;
using QuanLyNhanSu;
using QuanLyPhanSo;
using QuanLyDonThuc;
using QuanLyDaySo;
using QuanLyMaTrận;
using QuanLyDaThuc;
using QuanLyDayPhanSo;
using QuanLyLuongNhanVien;
using QuanLyKeThuaDaHinh;

namespace QuanLyBaiTap
{
    class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập mã hóa UTF-8 để hiển thị Tiếng Việt đầy đủ trên Terminal
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("==================================================");
                Console.WriteLine("        CHƯƠNG TRÌNH TỔNG HỢP OOP C# - MENU       ");
                Console.WriteLine("==================================================");
                Console.WriteLine(" 1. Bài 1.1: Quản lý tuổi sinh viên (SinhVien)");
                Console.WriteLine(" 2. Bài 1.2: Quản lý điểm tọa độ mặt phẳng (Point)");
                Console.WriteLine(" 3. Bài 1.3: Quản lý thông tin cá nhân (Person)");
                Console.WriteLine(" 4. Bài 1.4: Quản lý Phân số số thực và toán tử");
                Console.WriteLine(" 5. Bài 1.5: Quản lý Đơn thức, tính giá trị và đạo hàm");
                Console.WriteLine(" 6. Bài 2.1: Quản lý mảng điểm ArrayPoint (ArrayList & Indexer)");
                Console.WriteLine(" 7. Bài 2.2: Quản lý danh sách nhân khẩu (PersonList)");
                Console.WriteLine(" 8. Bài 2.3: Quản lý dãy số nguyên (DaySo & Số chẵn)");
                Console.WriteLine(" 9. Bài 2.4: Quản lý mảng 2 chiều Matrix (Indexer 2 chiều & Số nguyên tố)");
                Console.WriteLine(" 10. Bài 2.5: Quản lý Đa thức P(x) (Indexer & Tính giá trị Horner)");
                Console.WriteLine(" 11. Bài 2.6: Quản lý Dãy phân số (ListPhanSo & Tổng)");
                Console.WriteLine(" 12. Bài 2.7: Quản lý Lương Nhân viên (PhongBan & Tổng lương)");
                Console.WriteLine(" 13. Bài 3.1: Sắp xếp mảng đối tượng dùng Array.Sort()");
                Console.WriteLine(" 14. Bài 3.2: Sắp xếp mảng tổng quát bằng Interface (Mô phỏng Array.Sort)");
                Console.WriteLine(" 15. Bài 3.3: Sắp xếp mảng tổng quát bằng Delegate");
                Console.WriteLine(" 16. Bài 3.4: Xây dựng ConsoleMenu tổng quát giải PT bậc 2 qua Event");
                Console.WriteLine(" 17. Bài 3.5: Tính lương nhân viên kinh doanh & sản xuất (Kế thừa & Đa hình)");
                Console.WriteLine(" 18. Bài 3.6: Tính điểm thí sinh Chuyên & Siêu cúp (Kế thừa & Đa hình)");
                Console.WriteLine(" 0. Thoát chương trình");
                Console.WriteLine("==================================================");
                Console.Write("Nhập lựa chọn của bạn (Từ 0 đến 18): ");

                string choice = Console.ReadLine();
                Console.WriteLine();

                switch (choice)
                {
                    case "1":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 1.1 <<<");
                        ChayBai1_1();
                        break;
                    case "2":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 1.2 <<<");
                        ChayBai1_2();
                        break;
                    case "3":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 1.3 <<<");
                        ChayBai1_3();
                        break;
                    case "4":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 1.4 <<<");
                        ChayBai1_4();
                        break;
                    case "5":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 1.5 <<<");
                        ChayBai1_5();
                        break;
                    case "6":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.1 <<<");
                        ChayBai2_1();
                        break;
                    case "7":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.2 <<<");
                        ChayBai2_2();
                        break;
                    case "8":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.3 <<<");
                        ChayBai2_3();
                        break;
                    case "9":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.4 <<<");
                        ChayBai2_4();
                        break;
                    case "10":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.5 (ĐA THỨC) <<<");
                        ChayBai2_5();
                        break;
                    case "11":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.6 (DÃY PHÂN SỐ) <<<");
                        ChayBai2_6();
                        break;
                    case "12":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 2.7 (TÍNH LƯƠNG NHÂN VIÊN) <<<");
                        ChayBai2_7();
                        break;
                    case "13":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 3.1 (SẮP XẾP MẢNG ĐỐI TƯỢNG VỚI Array.Sort) <<<");
                        ChayBai3_1();
                        break;
                    case "14":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 3.2 (SẮP XẾP TỔNG QUÁT BẰNG INTERFACE) <<<");
                        ChayBai3_2();
                        break;
                    case "15":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 3.3 (SẮP XẾP TỔNG QUÁT BẰNG DELEGATE) <<<");
                        ChayBai3_3();
                        break;
                    case "16":
                        Console.WriteLine(">>> ĐANG CHUYỂN SANG GIAO DIỆN MENU GIẢI PT BẬC 2 (EVENT)... <<<");
                        System.Threading.Thread.Sleep(800);
                        ChayBai3_4();
                        break;
                    case "17":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 3.5 (TÍNH LƯƠNG NHÂN VIÊN - KẾ THỪA & ĐA HÌNH) <<<");
                        ChayBai3_5();
                        break;
                    case "18":
                        Console.WriteLine(">>> ĐANG CHẠY BÀI 3.6 (TÍNH ĐIỂM THÍ SINH - KẾ THỪA & ĐA HÌNH) <<<");
                        ChayBai3_6();
                        break;
                    case "0":
                        Console.WriteLine("Cảm ơn bạn đã sử dụng chương trình. Tạm biệt!");
                        return;
                    default:
                        Console.WriteLine("[Lỗi] Lựa chọn không hợp lệ! Vui lòng chỉ nhập từ 0 đến 18.");
                        break;
                }

                if (choice != "16") // Bài 3.4 dùng menu giao diện riêng biệt qua Event
                {
                    Console.WriteLine("\n--------------------------------------------------");
                    Console.Write("Nhấn phím bất kỳ để quay lại Menu chính...");
                    Console.ReadKey();
                }
            }
        }

        static void ChayBai1_1()
        {
            Bai1_1 sv1 = new Bai1_1();
            sv1.NhapThongTin();
            Console.WriteLine("\n--- KẾT QUẢ XUẤT ---");
            sv1.XuatThongTin();
        }

        static void ChayBai1_2()
        {
            Point diemA = new Point();
            diemA.Input("A");
            Console.WriteLine();
            Point diemB = new Point();
            diemB.Input("B");
            Console.WriteLine($"\nĐiểm A = {diemA} | Điểm B = {diemB}");
            Console.WriteLine($"Khoảng cách AB: {diemA.TinhKhoangCach(diemB):F2}");
        }

        static void ChayBai1_3()
        {
            Bai1_3 person = new Bai1_3();
            person.Input();
            Console.WriteLine("\n--- KẾT QUẢ XUẤT ---");
            person.Output();
            Console.WriteLine($"Kiểm tra IsLiving(): {person.IsLiving()}");
        }

        static void ChayBai1_4()
        {
            PhanSo ps1 = new PhanSo();
            ps1.Input("thứ nhất (PS1)");
            Console.WriteLine($"\nPS1 = {ps1}");
        }

        static void ChayBai1_5()
        {
            DonThuc dt = new DonThuc();
            dt.Input();
            Console.WriteLine($"P(x) = {dt}");
            Console.Write("\nNhập giá trị x để tính giá trị đơn thức P(x): ");
            if (double.TryParse(Console.ReadLine(), out double x))
            {
                Console.WriteLine($"-> P({x}) = {dt.TinhGiaTri(x)}");
            }
            Console.WriteLine($"[Đạo hàm] Q(x) = {dt.TinhDaoHam()}");
        }

        static void ChayBai2_1()
        {
            ArrayPoint arr = new ArrayPoint();
            arr.Input();
            arr.Output();
        }

        static void ChayBai2_2()
        {
            PersonList pList = new PersonList();
            pList.Input();
            pList.Output();
        }

        static void ChayBai2_3()
        {
            DaySo ds = new DaySo();
            ds.Input();
            ds.Output();
        }

        static void ChayBai2_4()
        {
            Matrix mat = new Matrix();
            mat.Input();
            mat.Output();
            mat.TimSoNguyenTo();
        }

        static void ChayBai2_5()
        {
            DaThuc dt = new DaThuc();
            dt.Input();
            dt.Output();
        }

        static void ChayBai2_6()
        {
            ListPhanSo dsp = new ListPhanSo();
            dsp.Input();
            dsp.Output();
            Console.WriteLine($"Tổng: {dsp.TinhTong()}");
        }

        static void ChayBai2_7()
        {
            PhongBan pb = new PhongBan();
            pb.Input();
            pb.Output();
            Console.WriteLine($"Tổng lương phòng ban: {pb.TinhTongLuong():N0} VNĐ");
        }

        static void ChayBai3_1()
        {
            QuanLySapXep qlsx = new QuanLySapXep();
            qlsx.Input();
            Console.WriteLine("\nDANH SÁCH TRƯỚC KHI SẮP XẾP:");
            qlsx.Output();
            qlsx.SapXepTangDan();
            Console.WriteLine("\nDANH SÁCH SAU KHI SẮP XẾP:");
            qlsx.Output();
        }

        static void ChayBai3_2()
        {
            QuanLySortTongQuat ql = new QuanLySortTongQuat();
            ql.Input();
            Console.WriteLine("\nDANH SÁCH TRƯỚC KHI SẮP XẾP:");
            ql.Output();
            ql.ThucHienSapXep();
            Console.WriteLine("\nDANH SÁCH SAU KHI SẮP XẾP:");
            ql.Output();
        }

        static void ChayBai3_3()
        {
            QuanLySortDelegate ql = new QuanLySortDelegate();
            ql.Input();
            Console.WriteLine("\nDANH SÁCH TRƯỚC KHI SẮP XẾP:");
            ql.Output();
            ql.SapXepTheoGiaTangDan();
            Console.WriteLine("\nDANH SÁCH SAU KHI SẮP XẾP:");
            ql.Output();
        }

        static void ChayBai3_4()
        {
            PTBac2Console app = new PTBac2Console();
            app.Run();
        }

        static void ChayBai3_5()
        {
            QuanLyLuongCongTy ql = new QuanLyLuongCongTy();
            ql.Input();
            ql.Output();
        }

        static void ChayBai3_6()
        {
            CuocThiTinHoc cuocThi = new CuocThiTinHoc();
            cuocThi.Input();
            cuocThi.Output();
        }
    }
}