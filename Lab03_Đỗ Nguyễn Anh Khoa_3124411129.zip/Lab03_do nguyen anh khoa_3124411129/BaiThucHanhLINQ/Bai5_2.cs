using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Bai5_2
{
    public static void ChayBai5_2()
    {
        List<MonHoc> dsMon = DuLieu.DS_Mon();

        Console.WriteLine("=== BÀI 5.2: THỐNG KÊ VÀ PHÂN NHÓM TRÊN LIST<MONHOC> ===");
        Console.WriteLine(new string('-', 50));

        // a. Cho biết tổng số môn hiện có
        int tongSoMon = dsMon.Count;
        Console.WriteLine($"a. Tổng số môn hiện có: {tongSoMon}");
        Console.WriteLine();

        // b. Đếm số môn có tên bắt đầu bằng “Lập trình”
        int soMonLapTrinh = dsMon.Count(m => m.TenMon.StartsWith("Lập trình", StringComparison.OrdinalIgnoreCase));
        Console.WriteLine($"b. Số môn có tên bắt đầu bằng 'Lập trình': {soMonLapTrinh}");
        Console.WriteLine();

        // c. Tính tổng số tiết của hệ Kỹ thuật viên (KTV)
        int tongSoTietKTV = dsMon.Where(m => m.He.Equals("KTV", StringComparison.OrdinalIgnoreCase))
                                 .Sum(m => m.SoTiet);
        Console.WriteLine($"c. Tổng số tiết của hệ KTV: {tongSoTietKTV}");
        Console.WriteLine();

        // d. Cho biết tổng số môn của mỗi hệ: Hệ, Tổng số môn
        Console.WriteLine("d. Tổng số môn của mỗi hệ:");
        var thongKeHe = dsMon.GroupBy(m => m.He)
                             .Select(g => new { He = g.Key, TongSoMon = g.Count() });
        foreach (var item in thongKeHe)
        {
            Console.WriteLine($"   - Hệ: {item.He} | Tổng số môn: {item.TongSoMon}");
        }
        Console.WriteLine();

        // e. Nhóm theo Số tiết; in Số tiết và Tổng số môn, sắp xếp giảm dần theo Số tiết
        Console.WriteLine("e. Nhóm theo số tiết (sắp xếp giảm dần theo số tiết):");
        var nhomTheoSoTiet = dsMon.GroupBy(m => m.SoTiet)
                                  .OrderByDescending(g => g.Key);
        foreach (var g in nhomTheoSoTiet)
        {
            Console.WriteLine($"   - Số tiết: {g.Key} | Tổng số môn: {g.Count()}");
        }
        Console.WriteLine();

        // f. Cho biết thông tin môn học có số tiết cao nhất
        int maxSoTiet = dsMon.Max(m => m.SoTiet);
        var monMaxTiet = dsMon.Where(m => m.SoTiet == maxSoTiet);
        Console.WriteLine("f. Môn học có số tiết cao nhất:");
        foreach (var m in monMaxTiet)
        {
            Console.WriteLine($"   - [{m.MaMon}] {m.TenMon} | Số tiết: {m.SoTiet} | Hệ: {m.He}");
        }
        Console.WriteLine();

        // g. Thống kê theo Hệ: tổng số môn, tổng số tiết, số tiết cao nhất, số tiết thấp nhất
        Console.WriteLine("g. Thống kê chi tiết theo Hệ:");
        var thongKeChiTietHe = dsMon.GroupBy(m => m.He)
                                    .Select(g => new
                                    {
                                        He = g.Key,
                                        TongMon = g.Count(),
                                        TongTiet = g.Sum(m => m.SoTiet),
                                        MaxTiet = g.Max(m => m.SoTiet),
                                        MinTiet = g.Min(m => m.SoTiet)
                                    });
        foreach (var item in thongKeChiTietHe)
        {
            Console.WriteLine($"   - Hệ: {item.He} | Tổng môn: {item.TongMon} | Tổng tiết: {item.TongTiet} | Max tiết: {item.MaxTiet} | Min tiết: {item.MinTiet}");
        }
        Console.WriteLine();

        // h. Liệt kê các môn học được phân nhóm theo Hệ
        Console.WriteLine("h. Liệt kê các môn học phân nhóm theo Hệ:");
        var nhomTheoHe = dsMon.GroupBy(m => m.He);
        foreach (var g in nhomTheoHe)
        {
            Console.WriteLine($"   [ Hệ: {g.Key} ]");
            foreach (var m in g)
            {
                Console.WriteLine($"      + [{m.MaMon}] {m.TenMon} ({m.SoTiet} tiết)");
            }
        }
        Console.WriteLine();

        // i. Liệt kê các môn học được phân nhóm theo Số tiết và tăng dần theo Số tiết
        Console.WriteLine("i. Liệt kê các môn học phân nhóm theo Số tiết (tăng dần):");
        var nhomTheoTietTang = dsMon.GroupBy(m => m.SoTiet)
                                    .OrderBy(g => g.Key);
        foreach (var g in nhomTheoTietTang)
        {
            Console.WriteLine($"   [ Số tiết: {g.Key} ]");
            foreach (var m in g)
            {
                Console.WriteLine($"      + [{m.MaMon}] {m.TenMon} - Hệ: {m.He}");
            }
        }
        Console.WriteLine();

        // j. Với hệ KTV, phân nhóm theo học phần HP2, HP3, HP4, HP5; sắp xếp theo Mã môn
        Console.WriteLine("j. Hệ KTV phân nhóm theo nhóm HP (HP2, HP3, HP4, HP5):");
        var nhomKTV = dsMon.Where(m => m.He.Equals("KTV", StringComparison.OrdinalIgnoreCase))
                           .GroupBy(m => m.MaMon.Substring(0, 3))
                           .OrderBy(g => g.Key);
        foreach (var g in nhomKTV)
        {
            Console.WriteLine($"   [ Nhóm {g.Key} ]");
            foreach (var m in g.OrderBy(x => x.MaMon))
            {
                Console.WriteLine($"      + [{m.MaMon}] {m.TenMon}");
            }
        }
        Console.WriteLine();

        // k. Phân nhóm theo Hệ, chỉ lấy các môn có Số tiết > 40; trong mỗi nhóm sắp xếp theo Mã môn
        Console.WriteLine("k. Phân nhóm theo Hệ (chỉ lấy Số tiết > 40, sắp xếp theo Mã môn):");
        var nhomLonHon40 = dsMon.Where(m => m.SoTiet > 40)
                                .GroupBy(m => m.He);
        foreach (var g in nhomLonHon40)
        {
            Console.WriteLine($"   [ Hệ: {g.Key} ]");
            foreach (var m in g.OrderBy(x => x.MaMon))
            {
                Console.WriteLine($"      + [{m.MaMon}] {m.TenMon} | Số tiết: {m.SoTiet}");
            }
        }
    }
}