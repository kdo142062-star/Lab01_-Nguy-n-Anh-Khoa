using System;

namespace QuanLyDonThuc
{
    public class DonThuc
    {
        // 1. Fields (Hệ số a là số thực, số mũ n là số nguyên không âm)
        private double heSo; // a
        private int soMu;    // n

        // 2. Constructors (Hàm khởi tạo)
        public DonThuc()
        {
            heSo = 0;
            soMu = 0;
        }

        public DonThuc(double heSo, int soMu)
        {
            HeSo = heSo;
            SoMu = soMu;
        }

        public DonThuc(DonThuc dt)
        {
            if (dt != null)
            {
                this.heSo = dt.heSo;
                this.soMu = dt.soMu;
            }
        }

        // 3. Properties (Thuộc tính đóng gói, kiểm tra dữ liệu an toàn)
        public double HeSo
        {
            get { return heSo; }
            set { heSo = value; }
        }

        public int SoMu
        {
            get { return soMu; }
            set 
            { 
                if (value >= 0)
                {
                    soMu = value;
                }
                else
                {
                    throw new ArgumentException("Số mũ n phải là số nguyên không âm (n >= 0)!");
                }
            }
        }

        // 4. Methods nghiệp vụ

        // Phương thức Input() có chống lỗi nhập sai
        public void Input()
        {
            Console.WriteLine("--- NHẬP THÔNG TIN ĐƠN THỨC P(x) = a * x^n ---");
            
            // Nhập hệ số a (số thực)
            while (true)
            {
                Console.Write("Nhập hệ số a (số thực): ");
                if (double.TryParse(Console.ReadLine(), out double a))
                {
                    heSo = a;
                    break;
                }
                Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập một số thực.");
            }

            // Nhập số mũ n (số nguyên không âm)
            while (true)
            {
                try
                {
                    Console.Write("Nhập số mũ n (số nguyên >= 0): ");
                    if (int.TryParse(Console.ReadLine(), out int n))
                    {
                        SoMu = n; // Gán qua Property để kiểm tra n >= 0
                        break;
                    }
                    else
                    {
                        Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập số nguyên.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }
        }

        // Override ToString() để hiển thị đơn thức đẹp mắt
        public override string ToString()
        {
            if (heSo == 0) return "0";
            if (soMu == 0) return $"{heSo}";
            if (soMu == 1) return $"{heSo}*x";
            return $"{heSo}*x^{soMu}";
        }

        // (a) Tính giá trị đơn thức P(x) với giá trị x cho trước
        public double TinhGiaTri(double x)
        {
            return heSo * Math.Pow(x, soMu);
        }

        // (b) Đạo hàm đơn thức: Q(x) = P'(x) = a * n * x^(n - 1)
        public DonThuc TinhDaoHam()
        {
            if (soMu == 0)
            {
                // Đạo hàm của hằng số là 0 (0 * x^0)
                return new DonThuc(0, 0);
            }
            else
            {
                double moiHeSo = heSo * soMu;
                int moiSoMu = soMu - 1;
                return new DonThuc(moiHeSo, moiSoMu);
            }
        }
    }
}