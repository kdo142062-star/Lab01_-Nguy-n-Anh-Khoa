using System;

namespace QuanLyDaThuc
{
    public class DaThuc
    {
        // 1. Field: Mảng chứa các hệ số của đa thức (a0, a1, a2, ..., an)
        // Hệ số a_i tương ứng với số hạng a_i * x^i
        private double[] heSo;

        // 2. Constructors (Các loại Constructor)

        // Default constructor (Đa thức rỗng)
        public DaThuc()
        {
            heSo = new double[0];
        }

        // Constructor có tham số bậc của đa thức (bậc n thì có n + 1 hệ số)
        public DaThuc(int bac)
        {
            if (bac >= 0)
            {
                heSo = new double[bac + 1];
            }
            else
            {
                heSo = new double[0];
            }
        }

        // Copy constructor
        public DaThuc(DaThuc other)
        {
            if (other != null && other.heSo != null)
            {
                heSo = new double[other.heSo.Length];
                Array.Copy(other.heSo, heSo, other.heSo.Length);
            }
            else
            {
                heSo = new double[0];
            }
        }

        // Thuộc tính lấy bậc của đa thức (Bậc = số lượng hệ số - 1)
        public int Bac
        {
            get { return heSo.Length - 1; }
        }

        // 3. Indexer để truy cập hệ số của đơn thức thứ i (a_i)
        public double this[int i]
        {
            get
            {
                if (i >= 0 && i < heSo.Length)
                {
                    return heSo[i];
                }
                throw new IndexOutOfRangeException("Chỉ số đơn thức (i) vượt quá bậc của đa thức!");
            }
            set
            {
                if (i >= 0 && i < heSo.Length)
                {
                    heSo[i] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException("Chỉ số đơn thức (i) vượt quá bậc của đa thức!");
                }
            }
        }

        // 4. Methods nghiệp vụ

        // Nhập đa thức
        public void Input()
        {
            Console.WriteLine("--- NHẬP ĐA THỨC P(x) ---");
            while (true)
            {
                Console.Write("Nhập bậc của đa thức n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n >= 0)
                {
                    heSo = new double[n + 1];
                    Console.WriteLine($"Nhập các hệ số từ bậc 0 đến bậc {n}:");
                    for (int i = 0; i <= n; i++)
                    {
                        while (true)
                        {
                            Console.Write($"  Nhập hệ số a{i} (của x^{i}): ");
                            if (double.TryParse(Console.ReadLine(), out double val))
                            {
                                heSo[i] = val;
                                break;
                            }
                            Console.WriteLine("  [Lỗi] Vui lòng nhập vào một số thực hợp lệ!");
                        }
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Bậc của đa thức phải là số nguyên không âm. Vui lòng nhập lại!");
            }
        }

        // Xuất đa thức dưới dạng toán học trực quan
        public void Output()
        {
            if (heSo == null || heSo.Length == 0)
            {
                Console.WriteLine("P(x) = 0");
                return;
            }

            string result = "P(x) = ";
            bool hasTerm = false;

            for (int i = 0; i < heSo.Length; i++)
            {
                double a = heSo[i];
                if (a == 0 && heSo.Length > 1) continue; // Bỏ qua hệ số bằng 0 (trừ khi đa thức chỉ có mỗi số 0)

                if (hasTerm)
                {
                    result += (a > 0) ? " + " : " - ";
                }
                else
                {
                    if (a < 0) result += "-";
                }

                double absA = Math.Abs(a);

                if (i == 0)
                {
                    result += absA;
                }
                else if (i == 1)
                {
                    result += (absA == 1) ? "x" : $"{absA}x";
                }
                else
                {
                    result += (absA == 1) ? $"x^{i}" : $"{absA}x^{i}";
                }
                hasTerm = true;
            }

            if (!hasTerm) result += "0";
            Console.WriteLine(result);
        }

        // Tính giá trị của đa thức tại giá trị x được nhập từ bàn phím (sử dụng thuật toán Horner tối ưu O(n))
        public double TinhGiaTri(double x)
        {
            if (heSo == null || heSo.Length == 0) return 0;

            double p = 0;
            // Thuật toán Horner: P(x) = a0 + x*(a1 + x*(a2 + ... + x*an))
            for (int i = heSo.Length - 1; i >= 0; i--)
            {
                p = p * x + heSo[i];
            }
            return p;
        }
    }
}