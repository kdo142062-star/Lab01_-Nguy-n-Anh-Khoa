using System;
using System.Globalization;
using System.Linq;

namespace QuanLyKeThuaDaHinh
{
    // Lớp cơ sở trừu tượng NhanVien
    public abstract class NhanVien
    {
        protected string maNV;
        protected string hoTen;

        public NhanVien()
        {
            maNV = "";
            hoTen = "";
        }

        public NhanVien(string maNV, string hoTen)
        {
            this.maNV = maNV;
            this.hoTen = hoTen;
        }

        public string MaNV => maNV;
        public string HoTen => hoTen;

        // Phương thức kiểm tra ID phải là chuỗi số thuần túy
        protected bool KiemTraID(string id)
        {
            return !string.IsNullOrWhiteSpace(id) && id.All(char.IsDigit);
        }

        // Phương thức kiểm tra Tên chỉ chứa chữ cái và khoảng trắng
        protected bool KiemTraTen(string name)
        {
            return !string.IsNullOrWhiteSpace(name) && name.All(c => char.IsLetter(c) || c == ' ');
        }

        public virtual void Input()
        {
            // Nhập và chuẩn hóa Mã Nhân Viên (Bắt buộc phải là số)
            while (true)
            {
                Console.Write("  - Nhập mã nhân viên (chỉ gồm các chữ số): ");
                string input = Console.ReadLine();
                if (KiemTraID(input))
                {
                    maNV = input;
                    break;
                }
                Console.WriteLine("  [Lỗi] Mã nhân viên phải là số nguyên dương! Vui lòng nhập lại.");
            }

            // Nhập và chuẩn hóa Họ Tên (Bắt buộc phải là chữ cái)
            while (true)
            {
                Console.Write("  - Nhập họ tên nhân viên (chỉ gồm chữ cái): ");
                string input = Console.ReadLine();
                if (KiemTraTen(input))
                {
                    // Chuẩn hóa khoảng trắng và viết hoa chữ cái đầu mỗi từ
                    hoTen = string.Join(" ", input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                                                  .Select(s => char.ToUpper(s[0]) + s.Substring(1).ToLower()));
                    break;
                }
                Console.WriteLine("  [Lỗi] Họ tên chỉ được chứa chữ cái và khoảng trắng! Vui lòng nhập lại.");
            }
        }

        // Phương thức trừu tượng tính lương (Đa hình)
        public abstract double TinhLuong();

        public virtual void Output()
        {
            Console.Write($"Mã NV: {maNV,-8} | Họ tên: {hoTen,-22}");
        }
    }

    // Lớp Nhân viên kinh doanh kế thừa từ NhanVien
    public class NhanVienKinhDoanh : NhanVien
    {
        private double luongCoBan;
        private int soHopDong;

        public NhanVienKinhDoanh() : base()
        {
            luongCoBan = 0;
            soHopDong = 0;
        }

        public override void Input()
        {
            base.Input(); // Gọi phương thức nhập của lớp cha (có kiểm tra ID và Tên)

            while (true)
            {
                Console.Write("  - Nhập lương cơ bản: ");
                string strLuong = Console.ReadLine();
                string cleanInput = strLuong.Trim().Replace(".", "").Replace(",", "").Replace(" ", "");
                if (double.TryParse(cleanInput, NumberStyles.Any, CultureInfo.InvariantCulture, out luongCoBan) && luongCoBan >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Lương cơ bản không hợp lệ! Vui lòng nhập lại.");
            }

            while (true)
            {
                Console.Write("  - Nhập số hợp đồng ký kết: ");
                if (int.TryParse(Console.ReadLine(), out soHopDong) && soHopDong >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Số hợp đồng phải là số nguyên không âm!");
            }
        }

        // Lương KD = Lương cơ bản + Số hợp đồng * 500.000 VNĐ
        public override double TinhLuong()
        {
            return luongCoBan + (soHopDong * 500000.0);
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($" | Loại: Kinh doanh    | Lương thực lĩnh: {TinhLuong(),12:N0} VNĐ");
        }
    }

    // Lớp Nhân viên sản xuất kế thừa từ NhanVien
    public class NhanVienSanXuat : NhanVien
    {
        private int soLuongSanPham;

        public NhanVienSanXuat() : base()
        {
            soLuongSanPham = 0;
        }

        public override void Input()
        {
            base.Input(); // Gọi phương thức nhập của lớp cha

            while (true)
            {
                Console.Write("  - Nhập số lượng sản phẩm: ");
                if (int.TryParse(Console.ReadLine(), out soLuongSanPham) && soLuongSanPham >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Số lượng sản phẩm phải là số nguyên không âm!");
            }
        }

        // Lương SX = Số sản phẩm * 1000. Nếu > 3000 sản phẩm thưởng thêm 5%
        public override double TinhLuong()
        {
            double luongCoSo = soLuongSanPham * 1000.0;
            if (soLuongSanPham > 3000)
            {
                return luongCoSo * 1.05; // Thưởng thêm 5%
            }
            return luongCoSo;
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($" | Loại: Sản xuất      | Lương thực lĩnh: {TinhLuong(),12:N0} VNĐ");
        }
    }

    // Lớp quản lý danh sách công ty tổng hợp đa hình
    public class QuanLyLuongCongTy
    {
        private NhanVien[] danhSachNV;

        public QuanLyLuongCongTy()
        {
            danhSachNV = new NhanVien[0];
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH NHÂN VIÊN CÔNG TY ---");
            while (true)
            {
                Console.Write("Nhập tổng số lượng nhân viên n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    danhSachNV = new NhanVien[n];
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nChọn loại nhân viên thứ {i + 1}:");
                        Console.WriteLine("  1. Nhân viên Kinh doanh");
                        Console.WriteLine("  2. Nhân viên Sản xuất");
                        Console.Write("Nhập lựa chọn (1 hoặc 2): ");
                        string loai = Console.ReadLine();

                        if (loai == "1")
                        {
                            danhSachNV[i] = new NhanVienKinhDoanh();
                        }
                        else if (loai == "2")
                        {
                            danhSachNV[i] = new NhanVienSanXuat();
                        }
                        else
                        {
                            Console.WriteLine("[Lỗi] Lựa chọn không hợp lệ, mặc định tạo Nhân viên Kinh doanh.");
                            danhSachNV[i] = new NhanVienKinhDoanh();
                        }

                        danhSachNV[i].Input();
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSachNV == null || danhSachNV.Length == 0)
            {
                Console.WriteLine("Danh sách nhân viên công ty trống!");
                return;
            }

            Console.WriteLine("\n==========================================================================");
            Console.WriteLine("                    DANH SÁCH LƯƠNG NHÂN VIÊN CÔNG TY                     ");
            Console.WriteLine("==========================================================================");
            foreach (var nv in danhSachNV)
            {
                nv.Output(); // Tính đa hình tại đây (tùy thuộc đối tượng thực tế sẽ gọi đúng phương thức tương ứng)
            }
            Console.WriteLine("==========================================================================");
        }
    }
}