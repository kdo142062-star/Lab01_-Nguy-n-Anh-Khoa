using System;

namespace Baitap01
{
    class Bai01
    {
        public static void ChayBai1()
        {
            // Yeu cau nguoi dung nhap ho ten
            Console.Write("Nhap ho ten cua ban: ");
            
            // Doc chuoi ky tu tu ban phim
            string hoTen = Console.ReadLine() ?? ""; 
            
            // Xuat ho ten da nhap ra man hinh console
            Console.WriteLine("Ho ten da nhap la: " + hoTen);
        }
    }
}