using System;
using System.Collections.Generic;
using System.Globalization;

namespace QuanLyKeThuaDaHinh
{
    // Lớp NhanVienSort thực thi interface IComparable<T> để cho phép Array.Sort() hoạt động
    public class NhanVienSort : IComparable<NhanVienSort>
    {
        private string hoTen;
        private double luong;

        public NhanVienSort()
        {
            hoTen = "";
            luong = 0;
        }

        public NhanVienSort(string hoTen, double luong)
        {
            this.hoTen = hoTen;
            this.luong = luong;
        }

        public string HoTen => hoTen;
        public double Luong => luong;

        public void Input()
        {
            Console.Write("  - Nhập họ tên nhân viên: ");
            hoTen = Console.ReadLine();

            while (true)
            {
                Console.Write("  - Nhập mức lương (VD: 100000 hoặc 100.000): ");
                string strTien = Console.ReadLine();
                string cleanInput = strTien.Trim().Replace(".", "").Replace(",", "").Replace(" ", "");

                if (double.TryParse(cleanInput, NumberStyles.Any, CultureInfo.InvariantCulture, out luong) && luong >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Mức lương không hợp lệ! Vui lòng nhập lại.");
            }
        }

        // Định nghĩa tiêu chí so sánh cho Array.Sort(): Sắp xếp tăng dần theo Mức lương
        public int CompareTo(NhanVienSort other)
        {
            if (other == null) return 1;
            return this.luong.CompareTo(other.luong);
        }

        public override string ToString()
        {
            return $"Họ tên: {hoTen,-20} | Lương: {luong,12:N0} VNĐ";
        }
    }

    // Lớp quản lý danh sách mảng đối tượng để áp dụng Array.Sort
    public class QuanLySapXep
    {
        private NhanVienSort[] danhSach;

        public QuanLySapXep()
        {
            danhSach = new NhanVienSort[0];
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH NHÂN VIÊN ĐỂ SẮP XẾP ---");
            while (true)
            {
                Console.Write("Nhập số lượng nhân viên n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    danhSach = new NhanVienSort[n];
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập nhân viên thứ {i + 1}:");
                        danhSach[i] = new NhanVienSort();
                        danhSach[i].Input();
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSach == null || danhSach.Length == 0)
            {
                Console.WriteLine("Danh sách đang trống!");
                return;
            }

            foreach (var nv in danhSach)
            {
                Console.WriteLine(nv);
            }
        }

        // Phương thức gọi Array.Sort tĩnh
        public void SapXepTangDan()
        {
            if (danhSach != null && danhSach.Length > 0)
            {
                Array.Sort(danhSach); // Sử dụng Array.Sort tĩnh nhờ interface IComparable
            }
        }
    }
}