using System;
using System.Windows.Forms;

namespace MayTinhBoTui
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Phải gọi frmMenu() ở đây để hiện bảng chọn bài đầu tiên
            Application.Run(new frmMenu());
        }
    }
}