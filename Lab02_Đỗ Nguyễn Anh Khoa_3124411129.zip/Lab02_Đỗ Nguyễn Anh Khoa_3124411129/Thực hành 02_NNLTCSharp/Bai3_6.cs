using System;
using System.Globalization;
using System.Linq;

namespace QuanLyKeThuaDaHinh
{
    // Lớp cơ sở trừu tượng Thí sinh
    public abstract class ThiSinh
    {
        protected string sbd;
        protected string hoTen;
        protected double bai1, bai2, bai3;
        protected double tongDiem;

        public ThiSinh()
        {
            sbd = "";
            hoTen = "";
            bai1 = bai2 = bai3 = 0;
            tongDiem = 0;
        }

        // Phương thức kiểm tra SBD phải là số nguyên dương
        protected bool KiemTraSBD(string id)
        {
            return !string.IsNullOrWhiteSpace(id) && id.All(char.IsDigit);
        }

        // Phương thức kiểm tra Họ Tên chỉ chứa chữ cái và khoảng trắng
        protected bool KiemTraTen(string name)
        {
            return !string.IsNullOrWhiteSpace(name) && name.All(c => char.IsLetter(c) || c == ' ');
        }

        // Phương thức kiểm tra điểm hợp lệ từ 0 đến 10
        protected double NhapDiemHopLe(string message)
        {
            double diem;
            while (true)
            {
                Console.Write(message);
                if (double.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture, out diem) && diem >= 0 && diem <= 10)
                {
                    return diem;
                }
                Console.WriteLine("  [Lỗi] Điểm số phải là số thực từ 0 đến 10! Vui lòng nhập lại.");
            }
        }

        public virtual void Input()
        {
            // Nhập Số báo danh (Bắt buộc là số)
            while (true)
            {
                Console.Write("  - Nhập số báo danh (chỉ gồm các chữ số): ");
                string input = Console.ReadLine();
                if (KiemTraSBD(input))
                {
                    sbd = input;
                    break;
                }
                Console.WriteLine("  [Lỗi] Số báo danh phải hoàn toàn là ký tự số! Vui lòng nhập lại.");
            }

            // Nhập Họ Tên (Bắt buộc là chữ)
            while (true)
            {
                Console.Write("  - Nhập họ tên thí sinh (chỉ gồm chữ cái): ");
                string input = Console.ReadLine();
                if (KiemTraTen(input))
                {
                    // Chuẩn hóa định dạng viết hoa chữ cái đầu mỗi từ
                    hoTen = string.Join(" ", input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                                                  .Select(s => char.ToUpper(s[0]) + s.Substring(1).ToLower()));
                    break;
                }
                Console.WriteLine("  [Lỗi] Họ tên chỉ được chứa chữ cái và khoảng trắng! Vui lòng nhập lại.");
            }

            // Nhập điểm 3 bài thi lập trình
            Console.WriteLine("  --- Nhập điểm 3 bài thi lập trình (0 - 10) ---");
            bai1 = NhapDiemHopLe("    + Điểm bài 1: ");
            bai2 = NhapDiemHopLe("    + Điểm bài 2: ");
            bai3 = NhapDiemHopLe("    + Điểm bài 3: ");
        }

        // Phương thức trừu tượng tính tổng điểm (Đa hình)
        public abstract void TinhTongDiem();

        public virtual void Output()
        {
            Console.Write($"SBD: {sbd,-6} | Họ tên: {hoTen,-20} | B1: {bai1,4:F1} | B2: {bai2,4:F1} | B3: {bai3,4:F1}");
        }
    }

    // Lớp Thí sinh Chuyên (Dành cho thí sinh chưa có giải, thi thêm Tiếng Anh)
    public class ThiSinhChuyen : ThiSinh
    {
        private double tiengAnh;

        public override void Input()
        {
            base.Input();
            tiengAnh = NhapDiemHopLe("  - Nhập điểm Tiếng Anh (0 - 10): ");
        }

        public override void TinhTongDiem()
        {
            double diemThuong = 0;
            if (tiengAnh >= 7 && tiengAnh <= 8)
            {
                diemThuong = 1.0;
            }
            else if (tiengAnh >= 9 && tiengAnh <= 10)
            {
                diemThuong = 2.0;
            }
            // Tổng 3 bài thi lập trình + Điểm thưởng tiếng Anh
            tongDiem = (bai1 + bai2 + bai3) + diemThuong;
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($" | TA: {tiengAnh,4:F1} | Loại: Chuyên     | Tổng điểm: {tongDiem,5:F1}");
        }
    }

    // Lớp Thí sinh Siêu cúp (Dành cho thí sinh đã có giải, thi thêm CSDL)
    public class ThiSinhSieuCup : ThiSinh
    {
        private double csdl;

        public override void Input()
        {
            base.Input();
            csdl = NhapDiemHopLe("  - Nhập điểm Cơ sở dữ liệu (0 - 10): ");
        }

        public override void TinhTongDiem()
        {
            // Tổng điểm của 4 bài thi (3 bài lập trình + CSDL)
            tongDiem = bai1 + bai2 + bai3 + csdl;
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($" | CSDL: {csdl,2:F1} | Loại: Siêu Cúp   | Tổng điểm: {tongDiem,5:F1}");
        }
    }

    // Lớp quản lý danh sách cuộc thi
    public class CuocThiTinHoc
    {
        private ThiSinh[] danhSachThiSinh;

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH THÍ SINH DỰ THI ---");
            while (true)
            {
                Console.Write("Nhập tổng số lượng thí sinh n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    danhSachThiSinh = new ThiSinh[n];
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nChọn đối tượng cho thí sinh thứ {i + 1}:");
                        Console.WriteLine("  1. Thí sinh Chuyên (Chưa có giải trước đây)");
                        Console.WriteLine("  2. Thí sinh Siêu cúp (Đã đoạt giải trước đây)");
                        Console.Write("Nhập lựa chọn (1 hoặc 2): ");
                        string loai = Console.ReadLine();

                        if (loai == "1")
                        {
                            danhSachThiSinh[i] = new ThiSinhChuyen();
                        }
                        else if (loai == "2")
                        {
                            danhSachThiSinh[i] = new ThiSinhSieuCup();
                        }
                        else
                        {
                            Console.WriteLine("[Lỗi] Lựa chọn không hợp lệ, mặc định tạo Thí sinh Chuyên.");
                            danhSachThiSinh[i] = new ThiSinhChuyen();
                        }

                        danhSachThiSinh[i].Input();
                        danhSachThiSinh[i].TinhTongDiem(); // Tự động tính tổng điểm sau khi nhập xong
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSachThiSinh == null || danhSachThiSinh.Length == 0)
            {
                Console.WriteLine("Danh sách thí sinh trống!");
                return;
            }

            Console.WriteLine("\n======================================================================================");
            Console.WriteLine("                        KẾT QUẢ TỔNG ĐIỂM THÍ SINH CUỘC THI TIN HỌC                   ");
            Console.WriteLine("======================================================================================");
            foreach (var ts in danhSachThiSinh)
            {
                ts.Output(); // Đa hình xuất thông tin và điểm số
            }
            Console.WriteLine("======================================================================================");
        }
    }
}