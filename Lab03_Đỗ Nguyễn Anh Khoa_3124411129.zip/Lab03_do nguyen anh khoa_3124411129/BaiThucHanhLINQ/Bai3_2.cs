using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Bai3_2
{
    public static void ChayBai3_2()
    {
        string[] monAn = { "Bún bò Huế", "Hủ tiếu heo", "Bánh canh", "Bánh mì",
        "Nước Cà phê", "Mì quảng", "Cơm tấm", "Nước Chanh dây", "Mì xào",
        "Bún riêu", "Bánh cuốn", "Mì gói", "Bún chả", "Hủ tiếu Nam vang" };

        Console.WriteLine("=== BÀI 3.2: THỐNG KÊ MẢNG CHUỖI ===");
        Console.WriteLine("Mảng ban đầu:");
        Console.WriteLine(string.Join(", ", monAn));
        Console.WriteLine(new string('-', 40));

        // a. Tìm các phần tử có chiều dài ngắn nhất và dài nhất
        int minLen = monAn.Min(s => s.Length);
        int maxLen = monAn.Max(s => s.Length);
        var nganNhat = monAn.Where(s => s.Length == minLen);
        var daiNhat = monAn.Where(s => s.Length == maxLen);

        Console.WriteLine("a. Phần tử ngắn nhất: " + string.Join(", ", nganNhat));
        Console.WriteLine("   Phần tử dài nhất: " + string.Join(", ", daiNhat));
        Console.WriteLine();

        // b. Phân nhóm theo từ đầu tiên của tên món và liệt kê các phần tử trong từng nhóm
        Console.WriteLine("b. Phân nhóm theo từ đầu tiên:");
        var nhomTheoTuDau = monAn.GroupBy(s => s.Split(' ')[0]);
        foreach (var nhom in nhomTheoTuDau)
        {
            Console.WriteLine($"   - Nhóm '{nhom.Key}': {string.Join(", ", nhom)}");
        }
        Console.WriteLine();

        // c. Đếm số phần tử có từ đầu tiên là “Bánh”
        int soLuongBanh = monAn.Count(s => s.Split(' ')[0].Equals("Bánh", StringComparison.OrdinalIgnoreCase));
        Console.WriteLine($"c. Số phần tử có từ đầu tiên là 'Bánh': {soLuongBanh}");
    }
}