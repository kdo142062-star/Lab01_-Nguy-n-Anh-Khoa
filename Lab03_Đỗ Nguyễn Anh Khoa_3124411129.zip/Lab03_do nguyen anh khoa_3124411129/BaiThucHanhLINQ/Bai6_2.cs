using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Bai6_2
{
    public static void ChayBai6_2()
    {
        List<MonHoc> dsMon = DuLieu.DS_Mon();
        List<He> dsHe = new List<He>
        {
            new He { MaHe = "KTV", TenHe = "Kỹ thuật viên" },
            new He { MaHe = "CD", TenHe = "Chuyên đề" },
            new He { MaHe = "QT", TenHe = "Chứng chỉ quốc tế" }
        };

        Console.WriteLine("=== BÀI 6.2: JOIN VÀ CÁC TOÁN TỬ TẬP HỢP ===");
        Console.WriteLine(new string('-', 50));

        // a. Dùng join để liệt kê: Tên hệ, Mã môn, Tên môn
        Console.WriteLine("a. Danh sách môn học theo hệ (Inner Join):");
        var qA = from m in dsMon
                 join h in dsHe on m.He equals h.MaHe
                 select new { h.TenHe, m.MaMon, m.TenMon };
        foreach (var item in qA)
        {
            Console.WriteLine($"   - [{item.TenHe}] {item.MaMon} : {item.TenMon}");
        }
        Console.WriteLine();

        // b. Liệt kê cả những hệ chưa có môn học (Left Outer Join)
        Console.WriteLine("b. Liệt kê cả hệ chưa có môn học (Left Outer Join):");
        var qB = from h in dsHe
                 join m in dsMon on h.MaHe equals m.He into g
                 from subM in g.DefaultIfEmpty()
                 select new { h.TenHe, MaMon = subM?.MaMon ?? "Không có", TenMon = subM?.TenMon ?? "Không có môn" };
        foreach (var item in qB)
        {
            Console.WriteLine($"   - [{item.TenHe}] Mã: {item.MaMon} | Môn: {item.TenMon}");
        }
        Console.WriteLine();

        // c. Liệt kê cả hệ chưa có môn học và môn học chưa khai báo hệ (Full Outer Join)
        Console.WriteLine("c. Hệ chưa có môn và môn chưa khai báo hệ (Full Outer Join):");
        var leftJoin = from h in dsHe
                       join m in dsMon on h.MaHe equals m.He into g
                       from subM in g.DefaultIfEmpty()
                       select new { TenHe = h.TenHe, MaMon = subM?.MaMon ?? "Chưa rõ", TenMon = subM?.TenMon ?? "Chưa rõ" };
        var rightJoin = from m in dsMon
                        join h in dsHe on m.He equals h.MaHe into g
                        from subH in g.DefaultIfEmpty()
                        select new { TenHe = subH?.TenHe ?? "Chưa khai báo hệ", m.MaMon, m.TenMon };
        var qC = leftJoin.Union(rightJoin);
        foreach (var item in qC)
        {
            Console.WriteLine($"   - [{item.TenHe}] {item.MaMon} : {item.TenMon}");
        }
        Console.WriteLine();

        // d. Chỉ liệt kê những hệ chưa có môn học và những môn học chưa khai báo hệ
        Console.WriteLine("d. Chỉ hệ chưa có môn học và môn chưa khai báo hệ:");
        var heChuaMon = from h in dsHe
                        join m in dsMon on h.MaHe equals m.He into g
                        where !g.Any()
                        select new { ThongTin = $"Hệ chưa có môn: {h.TenHe}" };
        var monChuaHe = from m in dsMon
                        where !dsHe.Any(h => h.MaHe == m.He)
                        select new { ThongTin = $"Môn chưa khai báo hệ: [{m.MaMon}] {m.TenMon}" };
        var qD = heChuaMon.Union(monChuaHe);
        foreach (var item in qD)
        {
            Console.WriteLine($"   - {item.ThongTin}");
        }
        Console.WriteLine();

        // e. Lấy 5 môn học đầu tiên có số tiết giảm dần; hiển thị Tên hệ, Mã môn, Tên môn, Số tiết
        Console.WriteLine("e. 5 môn học có số tiết giảm dần:");
        var qE = (from m in dsMon
                  join h in dsHe on m.He equals h.MaHe into g
                  from h in g.DefaultIfEmpty()
                  orderby m.SoTiet descending
                  select new { TenHe = h?.TenHe ?? "Chưa rõ", m.MaMon, m.TenMon, m.SoTiet }).Take(5);
        foreach (var item in qE)
        {
            Console.WriteLine($"   - [{item.TenHe}] {item.MaMon} - {item.TenMon} ({item.SoTiet} tiết)");
        }
        Console.WriteLine();

        // f. Cho biết tổng số môn học của mỗi hệ: Mã hệ, Tên hệ, Tổng số môn
        Console.WriteLine("f. Tổng số môn học của mỗi hệ:");
        var qF = from h in dsHe
                 join m in dsMon on h.MaHe equals m.He into g
                 select new { h.MaHe, h.TenHe, TongSoMon = g.Count() };
        foreach (var item in qF)
        {
            Console.WriteLine($"   - [{item.MaHe}] {item.TenHe}: {item.TongSoMon} môn");
        }
        Console.WriteLine();

        // g. Cho biết có bao nhiêu loại Số tiết khác nhau trong danh sách môn học
        int soLoaiSoTiet = dsMon.Select(m => m.SoTiet).Distinct().Count();
        Console.WriteLine($"g. Số lượng loại số tiết khác nhau trong danh sách: {soLoaiSoTiet}");
        Console.WriteLine();

        // h. Tìm môn học đầu tiên có tên bắt đầu bằng “Lập trình”
        var monDauTien = dsMon.FirstOrDefault(m => m.TenMon.StartsWith("Lập trình", StringComparison.OrdinalIgnoreCase));
        Console.WriteLine("h. Môn học đầu tiên có tên bắt đầu bằng 'Lập trình':");
        if (monDauTien != null)
        {
            Console.WriteLine($"   - [{monDauTien.MaMon}] {monDauTien.TenMon} (Hệ: {monDauTien.He}, {monDauTien.SoTiet} tiết)");
        }
        else
        {
            Console.WriteLine("   - Không tìm thấy môn học nào.");
        }
        Console.WriteLine();

        // i. Liệt kê các môn theo từng hệ, đánh số thứ tự trong mỗi nhóm
        Console.WriteLine("i. Liệt kê các môn theo từng hệ (có đánh số thứ tự):");
        var qI = from h in dsHe
                 join m in dsMon on h.MaHe equals m.He into g
                 select new { h.TenHe, DanhSachMon = g.ToList() };
        foreach (var nhom in qI)
        {
            Console.WriteLine($"   [ Hệ: {nhom.TenHe} ]");
            int stt = 1;
            foreach (var m in nhom.DanhSachMon)
            {
                Console.WriteLine($"      {stt}. [{m.MaMon}] {m.TenMon} ({m.SoTiet} tiết)");
                stt++;
            }
        }
    }
}