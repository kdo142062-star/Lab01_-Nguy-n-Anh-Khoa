using System;

namespace Baitap01
{
    // Xây dựng lớp SinhVien
    class SinhVien
    {
        public string MaSinhVien { get; set; } = string.Empty;
        public string HoTen { get; set; } = string.Empty;
        public string DiaChi { get; set; } = string.Empty;
        public int NamThuMấy { get; set; }

        // Phương thức nhập thông tin sinh viên từ bàn phím
        public void NhapThongTin()
        {
            Console.Write("Nhap ma sinh vien: ");
            MaSinhVien = Console.ReadLine() ?? "";

            Console.Write("Nhap ho ten sinh vien: ");
            HoTen = Console.ReadLine() ?? "";

            Console.Write("Nhap dia chi: ");
            DiaChi = Console.ReadLine() ?? "";

            Console.Write("Nhap sinh vien nam thu may (1, 2, 3,...): ");
            int nam;
            while (!int.TryParse(Console.ReadLine(), out nam) || nam <= 0)
            {
                Console.Write("Gia tri khong hop le. Vui lòng nhập lai nam thu may: ");
            }
            NamThuMấy = nam; // Gán giá trị hợp lệ vào property
        }

        // Phương thức xuất thông tin sinh viên ra màn hình
        public void XuatThongTin()
        {
            Console.WriteLine("\n--- THONG TIN SINH VIEN ---");
            Console.WriteLine($"Mã sinh viên : {MaSinhVien}");
            Console.WriteLine($"Họ tên       : {HoTen}");
            Console.WriteLine($"Địa chỉ      : {DiaChi}");
            Console.WriteLine($"Sinh viên năm: {NamThuMấy}");
        }
    }

    class Bai13
    {
        public static void ChayBai13()
        {
            Console.WriteLine("=== QUAN LY THONG TIN SINH VIEN (BAI 13) ===");
            
            // Khởi tạo đối tượng SinhVien
            SinhVien sv = new SinhVien();

            // Gọi phương thức nhập và xuất
            sv.NhapThongTin();
            sv.XuatThongTin();
        }
    }
}