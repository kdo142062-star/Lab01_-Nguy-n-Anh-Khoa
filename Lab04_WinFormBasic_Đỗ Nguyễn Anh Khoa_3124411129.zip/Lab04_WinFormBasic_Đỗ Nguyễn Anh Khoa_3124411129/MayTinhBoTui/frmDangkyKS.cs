using System;
using System.Drawing;
using System.Windows.Forms;

namespace MayTinhBoTui
{
    public partial class frmDangkyKS : Form
    {
        private Label? lblTieuDe;
        private Label? lblHoTen, lblDiaChi, lblSoNgay;
        private TextBox? txtHoTen, txtDiaChi, txtSoNgay;
        
        private GroupBox? grpLoaiPhong, grpTienNghi, grpDichVu;
        private RadioButton? radPhongDon, radPhongDoi, radPhongBa;
        private CheckBox? chkTivi, chkInternet, chkMayNuocNong;
        private CheckBox? chkKaraoke, chkAnSang;

        private Button? btnThanhToan, btnNhapMoi, btnTongKet, btnThoat;
        private Label? lblThanhTienText;
        private TextBox? lblThanhTienVal;
        private GroupBox? grpTongKet;
        private Label? lblSoLuot, lblTongTien;
        private TextBox? txtSoLuot, txtTongTien;

        // Biến lưu trữ tổng số lượt khách và tổng tiền (cộng dồn qua nhiều khách)
        private int tongSoLuotKhach = 0;
        private decimal tongTienThuDuoc = 0;

        public frmDangkyKS()
        {
            KhoiTaoGiaoDien();
            ThietLapTrangThaiBanDau();
        }

        private void KhoiTaoGiaoDien()
        {
            this.Text = "frmDangkyKS";
            this.Size = new Size(685, 395);
            this.StartPosition = FormStartPosition.CenterScreen;

            // 1. Tiêu đề
            lblTieuDe = new Label();
            lblTieuDe.Text = "KHÁCH SẠN THANH THANH - TRẢ PHÒNG";
            lblTieuDe.Font = new Font("Arial", 14, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.DarkOrange;
            lblTieuDe.Location = new Point(130, 15);
            lblTieuDe.AutoSize = true;
            this.Controls.Add(lblTieuDe);

            // 2. Nhập thông tin chung (Họ tên, địa chỉ, số ngày ở) kèm sự kiện Enter nhảy ô
            lblHoTen = new Label() { Text = "Họ và tên:", Location = new Point(30, 65), AutoSize = true };
            txtHoTen = new TextBox() { Location = new Point(115, 62), Size = new Size(230, 22) };
            txtHoTen.TextChanged += KiemTraDieuKienNhap;
            txtHoTen.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) { txtDiaChi?.Focus(); e.Handled = true; e.SuppressKeyPress = true; }
            };

            lblDiaChi = new Label() { Text = "Địa chỉ:", Location = new Point(30, 105), AutoSize = true };
            txtDiaChi = new TextBox() { Location = new Point(115, 102), Size = new Size(230, 22) };
            txtDiaChi.TextChanged += KiemTraDieuKienNhap;
            txtDiaChi.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) { txtSoNgay?.Focus(); e.Handled = true; e.SuppressKeyPress = true; }
            };

            lblSoNgay = new Label() { Text = "Số ngày ở:", Location = new Point(30, 145), AutoSize = true };
            txtSoNgay = new TextBox() { Location = new Point(115, 142), Size = new Size(70, 22) };
            txtSoNgay.TextChanged += KiemTraDieuKienNhap;
            txtSoNgay.KeyDown += (s, e) => {
                if (e.KeyCode == Keys.Enter) { 
                    if (btnThanhToan != null && btnThanhToan.Enabled) BtnThanhToan_Click(null, e); 
                    e.Handled = true; e.SuppressKeyPress = true; 
                }
            };

            this.Controls.AddRange(new Control[] { lblHoTen, txtHoTen, lblDiaChi, txtDiaChi, lblSoNgay, txtSoNgay });

            // 3. Nhóm Loại phòng
            grpLoaiPhong = new GroupBox() { Text = "Loại phòng", Location = new Point(30, 185), Size = new Size(115, 140) };
            radPhongDon = new RadioButton() { Text = "Phòng đơn", Location = new Point(10, 22), AutoSize = true, Checked = true };
            radPhongDoi = new RadioButton() { Text = "Phòng đôi", Location = new Point(10, 60), AutoSize = true };
            radPhongBa = new RadioButton() { Text = "Phòng ba", Location = new Point(10, 98), AutoSize = true };
            grpLoaiPhong.Controls.AddRange(new Control[] { radPhongDon, radPhongDoi, radPhongBa });

            // 4. Nhóm Tiện nghi
            grpTienNghi = new GroupBox() { Text = "Tiện nghi", Location = new Point(155, 185), Size = new Size(130, 140) };
            chkTivi = new CheckBox() { Text = "Tivi", Location = new Point(10, 22), AutoSize = true };
            chkInternet = new CheckBox() { Text = "Internet", Location = new Point(10, 60), AutoSize = true };
            chkMayNuocNong = new CheckBox() { Text = "Máy nước nóng", Location = new Point(10, 98), AutoSize = true };
            grpTienNghi.Controls.AddRange(new Control[] { chkTivi, chkInternet, chkMayNuocNong });

            // 5. Nhóm Dịch vụ
            grpDichVu = new GroupBox() { Text = "Dịch vụ", Location = new Point(295, 185), Size = new Size(110, 140) };
            chkKaraoke = new CheckBox() { Text = "Karaoke", Location = new Point(10, 40), AutoSize = true };
            chkAnSang = new CheckBox() { Text = "Ăn sáng", Location = new Point(10, 85), AutoSize = true };
            grpDichVu.Controls.AddRange(new Control[] { chkKaraoke, chkAnSang });

            this.Controls.AddRange(new Control[] { grpLoaiPhong, grpTienNghi, grpDichVu });

            // 6. Khu vực nút bấm & Thành tiền (Bên phải)
            btnThanhToan = new Button() { Text = "Thanh toán", Location = new Point(425, 60), Size = new Size(95, 30) };
            btnThanhToan.Click += BtnThanhToan_Click;

            btnNhapMoi = new Button() { Text = "Nhập mới", Location = new Point(535, 60), Size = new Size(95, 30) };
            btnNhapMoi.Click += BtnNhapMoi_Click;

            lblThanhTienText = new Label() { Text = "Thành tiền:", Location = new Point(425, 108), AutoSize = true };
            lblThanhTienVal = new TextBox() { Location = new Point(500, 105), Size = new Size(130, 22), ReadOnly = true };

            this.Controls.AddRange(new Control[] { btnThanhToan, btnNhapMoi, lblThanhTienText, lblThanhTienVal });

            // 7. Group Tổng kết
            grpTongKet = new GroupBox() { Text = "Thông tin tổng kết", Location = new Point(425, 140), Size = new Size(205, 140) };
            
            btnTongKet = new Button() { Text = "Tổng Kết", Location = new Point(15, 22), Size = new Size(175, 27) };
            btnTongKet.Click += BtnTongKet_Click;

            lblSoLuot = new Label() { Text = "Số lượt người:", Location = new Point(10, 62), AutoSize = true };
            txtSoLuot = new TextBox() { Location = new Point(95, 59), Size = new Size(95, 22), ReadOnly = true };

            lblTongTien = new Label() { Text = "Tổng số tiền:", Location = new Point(10, 98), AutoSize = true };
            txtTongTien = new TextBox() { Location = new Point(95, 95), Size = new Size(95, 22), ReadOnly = true };

            grpTongKet.Controls.AddRange(new Control[] { btnTongKet, lblSoLuot, txtSoLuot, lblTongTien, txtTongTien });
            this.Controls.Add(grpTongKet);

            // 8. Nút Thoát
            btnThoat = new Button() { Text = "Thoát", Location = new Point(425, 290), Size = new Size(205, 30) };
            btnThoat.Click += BtnThoat_Click;
            this.Controls.Add(btnThoat);
        }

        private void ThietLapTrangThaiBanDau()
        {
            if (txtHoTen != null) txtHoTen.Clear();
            if (txtDiaChi != null) txtDiaChi.Clear();
            if (txtSoNgay != null) txtSoNgay.Clear();
            if (lblThanhTienVal != null) lblThanhTienVal.Clear();

            if (radPhongDon != null) radPhongDon.Checked = true;
            if (chkTivi != null) chkTivi.Checked = false;
            if (chkInternet != null) chkInternet.Checked = false;
            if (chkMayNuocNong != null) chkMayNuocNong.Checked = false;
            if (chkKaraoke != null) chkKaraoke.Checked = false;
            if (chkAnSang != null) chkAnSang.Checked = false;

            if (btnThanhToan != null) btnThanhToan.Enabled = false;
            if (btnNhapMoi != null) btnNhapMoi.Enabled = false;

            txtHoTen?.Focus();
        }

        private void KiemTraDieuKienNhap(object? sender, EventArgs e)
        {
            if (txtHoTen != null && txtDiaChi != null && txtSoNgay != null && btnThanhToan != null)
            {
                if (!string.IsNullOrWhiteSpace(txtHoTen.Text) &&
                    !string.IsNullOrWhiteSpace(txtDiaChi.Text) &&
                    int.TryParse(txtSoNgay.Text, out int soNgay) && soNgay > 0)
                {
                    btnThanhToan.Enabled = true;
                }
                else
                {
                    btnThanhToan.Enabled = false;
                }
            }
        }

        private void BtnThanhToan_Click(object? sender, EventArgs e)
        {
            if (txtSoNgay == null || lblThanhTienVal == null || btnNhapMoi == null || btnTongKet == null || btnThanhToan == null) return;

            if (!int.TryParse(txtSoNgay.Text, out int soNgay) || soNgay <= 0)
            {
                MessageBox.Show("Số ngày ở phải là số nguyên lớn hơn 0!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSoNgay.Focus();
                return;
            }

            decimal giaPhong = 0;
            if (radPhongDon != null && radPhongDon.Checked) giaPhong = 300000;
            else if (radPhongDoi != null && radPhongDoi.Checked) giaPhong = 350000;
            else if (radPhongBa != null && radPhongBa.Checked) giaPhong = 400000;

            decimal tienTienNghi = 0;
            if (chkTivi != null && chkTivi.Checked) tienTienNghi += 10000;
            if (chkInternet != null && chkInternet.Checked) tienTienNghi += 10000;
            if (chkMayNuocNong != null && chkMayNuocNong.Checked) tienTienNghi += 10000;

            decimal tienDichVu = 0;
            if (chkKaraoke != null && chkKaraoke.Checked) tienDichVu += 50000;
            if (chkAnSang != null && chkAnSang.Checked) tienDichVu += 15000 * soNgay;

            decimal thanhTien = (giaPhong * soNgay) + tienTienNghi + tienDichVu;
            lblThanhTienVal.Text = thanhTien.ToString("N0") + " VNĐ";

            // Cộng dồn vào biến tổng kết chung
            tongSoLuotKhach++;
            tongTienThuDuoc += thanhTien;

            btnNhapMoi.Enabled = true;
            btnTongKet.Enabled = true;
            btnThanhToan.Enabled = false;
        }

        private void BtnNhapMoi_Click(object? sender, EventArgs e)
        {
            ThietLapTrangThaiBanDau();
        }

        private void BtnTongKet_Click(object? sender, EventArgs e)
        {
            if (txtSoLuot != null && txtTongTien != null && btnTongKet != null)
            {
                txtSoLuot.Text = tongSoLuotKhach.ToString();
                txtTongTien.Text = tongTienThuDuoc.ToString("N0") + " VNĐ";

                tongSoLuotKhach = 0;
                tongTienThuDuoc = 0;

                btnTongKet.Enabled = false;
            }
        }

        private void BtnThoat_Click(object? sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi chương trình không?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}