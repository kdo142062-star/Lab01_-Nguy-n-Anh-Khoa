using System;

namespace Baitap01
{
    class Bai04
    {
        public static void ChayBai4()
        {
            // Bài 4: Tính x mũ y nhưng có kiểm tra lỗi nhập không phải số nguyên
            Console.WriteLine("=== CHUONG TRINH TINH LUY THUA (BAI 4) ===");
            
            // Kiểm tra số x
            Console.Write("Nhap so nguyen x: ");
            string inputX = Console.ReadLine();
            if (!int.TryParse(inputX, out int x))
            {
                Console.WriteLine("Loi: Gia tri nhap vao cho x khong phải la so nguyen hop le!");
                return; // Dừng chương trình luôn nếu nhập sai
            }

            // Kiểm tra số y
            Console.Write("Nhap so nguyen y: ");
            string inputY = Console.ReadLine();
            if (!int.TryParse(inputY, out int y))
            {
                Console.WriteLine("Loi: Gia tri nhap vao cho y khong phải la so nguyen hop le!");
                return; // Dừng chương trình luôn nếu nhập sai
            }

            // Nếu cả x và y đều hợp lệ thì tiến hành tính toán
            double ketQua = Math.Pow(x, y);
            Console.WriteLine($"Ket qua cua {x} mu {y} la: {ketQua}");
        }
    }
}