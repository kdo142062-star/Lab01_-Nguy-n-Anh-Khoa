using System;
using System.Collections.Generic;

namespace BaiThucHanhLINQ;

public class He
{
    public string MaHe { get; set; } = "";
    public string TenHe { get; set; } = "";
}

class Bai6_1
{
    public static void ChayBai6_1()
    {
        List<He> dsHe = new List<He>
        {
            new He { MaHe = "KTV", TenHe = "Kỹ thuật viên" },
            new He { MaHe = "CD", TenHe = "Chuyên đề" },
            new He { MaHe = "QT", TenHe = "Chứng chỉ quốc tế" }
        };

        Console.WriteLine("=== BÀI 6.1: XÂY DỰNG NGUỒN DỮ LIỆU HỆ (HE) ===");
        Console.WriteLine($"Đã tải thành công {dsHe.Count} hệ đào tạo vào hệ thống:\n");
        foreach (var h in dsHe)
        {
            Console.WriteLine($"   - Mã hệ: [{h.MaHe}] | Tên hệ: {h.TenHe}");
        }
    }
}