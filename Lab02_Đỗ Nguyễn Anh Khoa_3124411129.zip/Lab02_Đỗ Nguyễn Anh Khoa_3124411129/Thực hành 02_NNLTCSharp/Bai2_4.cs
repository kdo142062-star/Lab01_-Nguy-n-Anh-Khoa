using System;

namespace QuanLyMaTrận
{
    public class Matrix
    {
        // 1. Field: Mảng 2 chiều số nguyên
        private int[,] data;

        // 2. Constructors (Các loại Constructor)

        // Default constructor (Ma trận rỗng 0x0)
        public Matrix()
        {
            data = new int[0, 0];
        }

        // Constructor có tham số kích thước n dòng, m cột
        public Matrix(int n, int m)
        {
            if (n > 0 && m > 0)
            {
                data = new int[n, m];
            }
            else
            {
                data = new int[0, 0];
            }
        }

        // Copy constructor
        public Matrix(Matrix other)
        {
            if (other != null && other.data != null)
            {
                int rows = other.Rows;
                int cols = other.Cols;
                data = new int[rows, cols];
                Array.Copy(other.data, data, other.data.Length);
            }
            else
            {
                data = new int[0, 0];
            }
        }

        // Các thuộc tính lấy số dòng, số cột
        public int Rows
        {
            get { return data != null ? data.GetLength(0) : 0; }
        }

        public int Cols
        {
            get { return data != null ? data.GetLength(1) : 0; }
        }

        // 3. Indexer 2 chiều cho phép truy cập phần tử tại vị trí (i, j)
        public int this[int i, int j]
        {
            get
            {
                if (i >= 0 && i < Rows && j >= 0 && j < Cols)
                {
                    return data[i, j];
                }
                throw new IndexOutOfRangeException("Chỉ số dòng (i) hoặc cột (j) vượt quá giới hạn ma trận!");
            }
            set
            {
                if (i >= 0 && i < Rows && j >= 0 && j < Cols)
                {
                    data[i, j] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException("Chỉ số dòng (i) hoặc cột (j) vượt quá giới hạn ma trận!");
                }
            }
        }

        // 4. Methods nghiệp vụ

        // Nhập ma trận n x m
        public void Input()
        {
            Console.WriteLine("--- NHẬP MẢNG 2 CHIỀU (MATRIX) ---");
            int n, m;
            while (true)
            {
                Console.Write("Nhập số dòng n: ");
                if (int.TryParse(Console.ReadLine(), out n) && n > 0) break;
                Console.WriteLine("[Lỗi] Số dòng phải là số nguyên lớn hơn 0!");
            }

            while (true)
            {
                Console.Write("Nhập số cột m: ");
                if (int.TryParse(Console.ReadLine(), out m) && m > 0) break;
                Console.WriteLine("[Lỗi] Số cột phải là số nguyên lớn hơn 0!");
            }

            data = new int[n, m];
            Console.WriteLine($"\nBắt đầu nhập các phần tử cho ma trận {n}x{m}:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    while (true)
                    {
                        Console.Write($"  Nhập phần tử [{i},{j}]: ");
                        if (int.TryParse(Console.ReadLine(), out int val))
                        {
                            data[i, j] = val;
                            break;
                        }
                        Console.WriteLine("  [Lỗi] Vui lòng nhập số nguyên hợp lệ!");
                    }
                }
            }
        }

        // Xuất ma trận dưới dạng bảng đẹp mắt
        public void Output()
        {
            if (Rows == 0 || Cols == 0)
            {
                Console.WriteLine("Ma trận đang trống!");
                return;
            }

            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Cols; j++)
                {
                    Console.Write($"{data[i, j],-6} ");
                }
                Console.WriteLine();
            }
        }

        // Hàm phụ trợ kiểm tra số nguyên tố tối ưu
        private bool IsPrime(int num)
        {
            if (num < 2) return false;
            for (int i = 2; i * i <= num; i++)
            {
                if (num % i == 0) return false;
            }
            return true;
        }

        // Tìm và trả về danh sách các số nguyên tố trong mảng (hoặc in trực tiếp)
        public void TimSoNguyenTo()
        {
            if (Rows == 0 || Cols == 0)
            {
                Console.WriteLine("Ma trận đang trống!");
                return;
            }

            bool found = false;
            Console.Write("Các số nguyên tố có trong ma trận: ");
            for (int i = 0; i < Rows; i++)
            {
                for (int j = 0; j < Cols; j++)
                {
                    if (IsPrime(data[i, j]))
                    {
                        Console.Write($"{data[i, j]} ");
                        found = true;
                    }
                }
            }
            if (!found)
            {
                Console.Write("Không có số nguyên tố nào trong ma trận!");
            }
            Console.WriteLine();
        }
    }
}