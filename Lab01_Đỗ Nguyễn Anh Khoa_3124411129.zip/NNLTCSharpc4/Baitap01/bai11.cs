using System;

namespace Baitap01
{
    class Bai11
    {
        // Phương thức thành viên trả về chuỗi là đảo của một chuỗi
        public string DaoNguoc(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return s;
            }

            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }

        public static void ChayBai11()
        {
            Console.WriteLine("=== DAO NGUOC CHUOI (BAI 11) ===");
            
            Console.Write("Nhap vao mot chuoi bat ky: ");
            string input = Console.ReadLine();

            // Khởi tạo đối tượng của lớp Bai11 để gọi phương thức thành viên
            Bai11 xuLyChuoi = new Bai11();
            string ketQua = xuLyChuoi.DaoNguoc(input);

            Console.WriteLine($"Chuoi sau khi dao nguoc la: {ketQua}");
        }
    }
}