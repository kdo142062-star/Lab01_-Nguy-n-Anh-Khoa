using System;

namespace Baitap01
{
    class Bai06
    {
        // Phương thức tìm giá trị lớn nhất của 3 số nguyên (có return giá trị)
        public static int TimMax(int a, int b, int c)
        {
            int max = a;
            if (b > max) max = b;
            if (c > max) max = c;
            return max;
        }

        public static void ChayBai6()
        {
            Console.WriteLine("=== TIM GIA TRI LON NHAT CUA 3 SO (BAI 6) ===");
            
            Console.Write("Nhap so thu nhat (a): ");
            int a = int.Parse(Console.ReadLine());

            Console.Write("Nhap so thu hai (b): ");
            int b = int.Parse(Console.ReadLine());

            Console.Write("Nhap so thu ba (c): ");
            int c = int.Parse(Console.ReadLine());

            // Gọi phương thức và nhận giá trị trả về
            int soLonNhat = TimMax(a, b, c);

            Console.WriteLine($"So lon nhat trong ba so ({a}, {b}, {c}) la: {soLonNhat}");
        }
    }
}