using System;
using System.Collections.Generic;
using QuanLyNhanSu; 

namespace QuanLyNhanSu
{
    public class PersonList
    {
        // Sử dụng lớp Bai1_3 thay cho Person
        private List<Bai1_3> listPersons;

        public PersonList()
        {
            listPersons = new List<Bai1_3>();
        }

        public PersonList(PersonList other)
        {
            listPersons = new List<Bai1_3>();
            if (other != null && other.listPersons != null)
            {
                foreach (var p in other.listPersons)
                {
                    listPersons.Add(new Bai1_3(p)); 
                }
            }
        }

        public int Count
        {
            get { return listPersons.Count; }
        }

        public Bai1_3 this[int index]
        {
            get
            {
                if (index >= 0 && index < listPersons.Count)
                {
                    return listPersons[index];
                }
                throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn danh sách nhân khẩu!");
            }
            set
            {
                if (index >= 0 && index < listPersons.Count)
                {
                    listPersons[index] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException("Chỉ số (index) vượt quá giới hạn danh sách nhân khẩu!");
                }
            }
        }

        public void Add(Bai1_3 x)
        {
            if (x != null)
            {
                listPersons.Add(x);
            }
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP DANH SÁCH NHÂN KHẨU (PersonList) ---");
            while (true)
            {
                Console.Write("Nhập số lượng nhân khẩu n: ");
                if (int.TryParse(Console.ReadLine(), out int n) && n > 0)
                {
                    listPersons.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập thông tin cho người thứ {i + 1}:");
                        Bai1_3 p = new Bai1_3();
                        p.Input(); 
                        listPersons.Add(p);
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (listPersons.Count == 0)
            {
                Console.WriteLine("Danh sách nhân khẩu đang trống!");
                return;
            }

            Console.WriteLine($"{"STT",-5} | {"Họ tên",-20} | {"Trạng thái"}");
            Console.WriteLine(new string('-', 45));
            for (int i = 0; i < listPersons.Count; i++)
            {
                Console.Write($"[{i + 1}]   | ");
                listPersons[i].Output(); 
            }
        }

        public PersonList LivingPeople()
        {
            PersonList livingList = new PersonList();
            foreach (var p in listPersons)
            {
                if (p.IsLiving())
                {
                    livingList.Add(new Bai1_3(p)); 
                }
            }
            return livingList;
        }
    }
}