using System;
using System.Collections.Generic;
using System.Globalization;

namespace QuanLyLuongNhanVien
{
    // Lớp đại diện cho một Nhân viên
    public class NhanVien
    {
        private string hoTen;
        private double mucLuong; // Lương cơ bản
        private int soNgayVang;

        public NhanVien()
        {
            hoTen = "";
            mucLuong = 0;
            soNgayVang = 0;
        }

        public NhanVien(string hoTen, double mucLuong, int soNgayVang)
        {
            this.hoTen = hoTen;
            this.mucLuong = mucLuong;
            this.soNgayVang = soNgayVang;
        }

        // Copy constructor
        public NhanVien(NhanVien other)
        {
            if (other != null)
            {
                this.hoTen = other.hoTen;
                this.mucLuong = other.mucLuong;
                this.soNgayVang = other.soNgayVang;
            }
        }

        public string HoTen => hoTen;
        public double MucLuong => mucLuong;
        public int SoNgayVang => soNgayVang;

        // Phương thức hỗ trợ đọc số tiền linh hoạt: nhận cả "100.000", "100000", "10.000.000"
        public static bool TryParseTien(string input, out double result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(input)) return false;

            // Xóa sạch các ký tự phân cách hàng nghìn (dấu chấm, phẩy, khoảng trắng) để tránh lỗi định dạng
            string cleanInput = input.Trim().Replace(".", "").Replace(",", "").Replace(" ", "");

            return double.TryParse(cleanInput, NumberStyles.Any, CultureInfo.InvariantCulture, out result);
        }

        public void Input()
        {
            Console.Write("  - Nhập họ tên nhân viên: ");
            hoTen = Console.ReadLine();

            while (true)
            {
                // Gợi ý: Bạn có thể nhập liền (vd: 100000) để tránh bị Terminal tự động nhảy số khi gõ dấu chấm
                Console.Write("  - Nhập mức lương (VD: 100000 hoặc 100.000): ");
                string strTien = Console.ReadLine();
                
                if (TryParseTien(strTien, out mucLuong) && mucLuong >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Mức lương không hợp lệ! Vui lòng nhập lại số tiền.");
            }

            while (true)
            {
                Console.Write("  - Nhập số ngày vắng: ");
                if (int.TryParse(Console.ReadLine(), out soNgayVang) && soNgayVang >= 0)
                {
                    break;
                }
                Console.WriteLine("  [Lỗi] Số ngày vắng phải là số nguyên không âm! Vui lòng nhập lại.");
            }
        }

        // Tính thực lĩnh sau khi trừ tiền vắng (1 ngày vắng = 100.000 VNĐ)
        public double TinhThucLinh()
        {
            double thucLinh = mucLuong - (soNgayVang * 100000.0);
            return thucLinh > 0 ? thucLinh : 0;
        }

        public override string ToString()
        {
            return $"Họ tên: {hoTen,-20} | Lương cơ bản: {mucLuong,12:N0} VNĐ | Vắng: {soNgayVang,2} ngày | Thực lĩnh: {TinhThucLinh(),12:N0} VNĐ";
        }
    }

    // Lớp quản lý phòng ban chứa danh sách n nhân viên
    public class PhongBan
    {
        private List<NhanVien> danhSachNV;

        public PhongBan()
        {
            danhSachNV = new List<NhanVien>();
        }

        public PhongBan(int n)
        {
            danhSachNV = new List<NhanVien>();
            for (int i = 0; i < n; i++)
            {
                danhSachNV.Add(new NhanVien());
            }
        }

        // Copy constructor cho phòng ban
        public PhongBan(PhongBan other)
        {
            danhSachNV = new List<NhanVien>();
            if (other != null && other.danhSachNV != null)
            {
                foreach (var nv in other.danhSachNV)
                {
                    danhSachNV.Add(new NhanVien(nv));
                }
            }
        }

        public int Count => danhSachNV.Count;

        // Indexer để truy cập nhân viên thứ i
        public NhanVien this[int index]
        {
            get
            {
                if (index >= 0 && index < danhSachNV.Count)
                    return danhSachNV[index];
                throw new IndexOutOfRangeException("Chỉ số nhân viên vượt quá giới hạn phòng ban!");
            }
            set
            {
                if (index >= 0 && index < danhSachNV.Count && value != null)
                    danhSachNV[index] = value;
                else
                    throw new IndexOutOfRangeException("Chỉ số hoặc đối tượng nhân viên không hợp lệ!");
            }
        }

        public void Input()
        {
            Console.WriteLine("--- NHẬP THÔNG TIN PHÒNG BAN ---");
            while (true)
            {
                Console.Write("Nhập số lượng nhân viên n của phòng ban: ");
                string strN = Console.ReadLine();
                if (int.TryParse(strN, out int n) && n > 0)
                {
                    danhSachNV.Clear();
                    for (int i = 0; i < n; i++)
                    {
                        Console.WriteLine($"\nNhập thông tin nhân viên thứ {i + 1}:");
                        NhanVien nv = new NhanVien();
                        nv.Input();
                        danhSachNV.Add(nv);
                    }
                    break;
                }
                Console.WriteLine("[Lỗi] Số lượng nhân viên phải là số nguyên lớn hơn 0. Vui lòng nhập lại!");
            }
        }

        public void Output()
        {
            if (danhSachNV == null || danhSachNV.Count == 0)
            {
                Console.WriteLine("Phòng ban chưa có nhân viên nào!");
                return;
            }

            foreach (var nv in danhSachNV)
            {
                Console.WriteLine(nv);
            }
        }

        // Tính tổng lương thực lĩnh của toàn bộ phòng ban
        public double TinhTongLuong()
        {
            double tongLuong = 0;
            foreach (var nv in danhSachNV)
            {
                tongLuong += nv.TinhThucLinh();
            }
            return tongLuong;
        }
    }
}