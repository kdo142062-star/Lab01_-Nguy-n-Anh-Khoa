using System;

namespace QuanLySinhVien
{
    public class Bai1_1
    {
        // 1. Fields (Trường dữ liệu)
        private string hoTen;
        private int namSinh;

        // 2. Constructors (Hàm khởi tạo)
        // a. Constructor mặc định
        public Bai1_1()
        {
            hoTen = "Chưa có tên";
            namSinh = 2000;
        }

        // b. Constructor có tham số
        public Bai1_1(string hoTen, int namSinh)
        {
            HoTen = hoTen;
            NamSinh = namSinh;
        }

        // c. Constructor sao chép (Copy Constructor)
        public Bai1_1(Bai1_1 svKhac)
        {
            if (svKhac != null)
            {
                this.hoTen = svKhac.hoTen;
                this.namSinh = svKhac.namSinh;
            }
        }

        // 3. Properties (Thuộc tính đóng gói, kiểm tra dữ liệu hợp lệ)
        public string HoTen
        {
            get { return hoTen; }
            set 
            { 
                if (!string.IsNullOrWhiteSpace(value))
                {
                    hoTen = value.Trim();
                }
                else
                {
                    throw new ArgumentException("Họ tên không được để trống!");
                }
            }
        }

        public int NamSinh
        {
            get { return namSinh; }
            set 
            { 
                int namHienTai = DateTime.Now.Year;
                if (value >= 1900 && value <= namHienTai)
                {
                    namSinh = value;
                }
                else
                {
                    throw new ArgumentException($"Năm sinh phải từ 1900 đến {namHienTai}!");
                }
            }
        }

        // 4. Methods (Phương thức nghiệp vụ)
        // Phương thức tính tuổi
        public int TinhTuoi()
        {
            return DateTime.Now.Year - namSinh;
        }

        // Phương thức xuất thông tin
        public void XuatThongTin()
        {
            Console.WriteLine($"-> Họ tên : {HoTen}");
            Console.WriteLine($"-> Năm sinh: {NamSinh}");
            Console.WriteLine($"-> Tuổi    : {TinhTuoi()}");
        }

        // Phương thức nhập thông tin (có cơ chế bắt lỗi, sai có thể nhập lại ngay)
        public void NhapThongTin()
        {
            Console.WriteLine("--- NHẬP THÔNG TIN SINH VIÊN ---");
            
            // Vòng lặp nhập họ tên (nếu để trống sẽ báo lỗi và bắt nhập lại)
            while (true)
            {
                try
                {
                    Console.Write("Nhập họ tên sinh viên: ");
                    string inputTen = Console.ReadLine();
                    HoTen = inputTen; 
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }

            // Vòng lặp nhập năm sinh (nếu nhập sai định dạng hoặc ngoài khoảng sẽ bắt nhập lại)
            while (true)
            {
                try
                {
                    Console.Write("Nhập năm sinh (ví dụ: 2004): ");
                    string inputNam = Console.ReadLine();
                    
                    if (int.TryParse(inputNam, out int nam))
                    {
                        NamSinh = nam; 
                        break;
                    }
                    else
                    {
                        Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập vào một số nguyên.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }
        }

        // 5. Phương thức tĩnh (Static Method)
        public static int LayNamHienTai()
        {
            return DateTime.Now.Year;
        }

        // 6. Đa năng hóa toán tử (Operator Overloading)
        public static bool operator >(Bai1_1 sv1, Bai1_1 sv2)
        {
            return sv1.TinhTuoi() > sv2.TinhTuoi();
        }

        public static bool operator <(Bai1_1 sv1, Bai1_1 sv2)
        {
            return sv1.TinhTuoi() < sv2.TinhTuoi();
        }
    }
}