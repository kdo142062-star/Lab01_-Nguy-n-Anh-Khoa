using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Bai5_1
{
    public static void ChayBai5_1()
    {
        List<MonHoc> dsMon = DuLieu.DS_Mon();

        Console.WriteLine("=== BÀI 5.1: TRUY VẤN CƠ BẢN TRÊN LIST<MONHOC> ===");
        Console.WriteLine(new string('-', 50));

        // a. Liệt kê tên các môn học bắt đầu bằng “Lập trình”
        Console.WriteLine("a. Các môn học bắt đầu bằng 'Lập trình':");
        var kqA = dsMon.Where(m => m.TenMon.StartsWith("Lập trình", StringComparison.OrdinalIgnoreCase));
        foreach (var m in kqA)
        {
            Console.WriteLine($"   - {m.TenMon}");
        }
        Console.WriteLine();

        // b. Liệt kê các môn thuộc hệ “CD”, sắp xếp số tiết giảm dần rồi mã môn tăng dần
        Console.WriteLine("b. Các môn thuộc hệ 'CD' (sắp xếp số tiết giảm dần, mã môn tăng dần):");
        var kqB = dsMon.Where(m => m.He.Equals("CD", StringComparison.OrdinalIgnoreCase))
                       .OrderByDescending(m => m.SoTiet)
                       .ThenBy(m => m.MaMon);
        foreach (var m in kqB)
        {
            Console.WriteLine($"   - [{m.MaMon}] {m.TenMon} | Số tiết: {m.SoTiet} | Hệ: {m.He}");
        }
        Console.WriteLine();

        // c. Liệt kê các môn có tên chứa từ “web”, chỉ lấy Tên môn và Hệ
        Console.WriteLine("c. Các môn có tên chứa từ 'Web' (chỉ lấy Tên và Hệ):");
        var kqC = dsMon.Where(m => m.TenMon.IndexOf("web", StringComparison.OrdinalIgnoreCase) >= 0)
                       .Select(m => new { m.TenMon, m.He });
        foreach (var m in kqC)
        {
            Console.WriteLine($"   - Tên: {m.TenMon} | Hệ: {m.He}");
        }
        Console.WriteLine();

        // d. Liệt kê các môn thuộc hệ “KTV”, sắp xếp tăng dần theo Mã môn
        Console.WriteLine("d. Các môn thuộc hệ 'KTV' (sắp xếp tăng dần theo Mã môn):");
        var kqD = dsMon.Where(m => m.He.Equals("KTV", StringComparison.OrdinalIgnoreCase))
                       .OrderBy(m => m.MaMon);
        foreach (var m in kqD)
        {
            Console.WriteLine($"   - [{m.MaMon}] {m.TenMon} | Hệ: {m.He} | Số tiết: {m.SoTiet}");
        }
    }
}