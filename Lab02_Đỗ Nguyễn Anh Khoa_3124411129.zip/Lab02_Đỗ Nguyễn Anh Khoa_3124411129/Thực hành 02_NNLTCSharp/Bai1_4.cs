using System;

namespace QuanLyPhanSo
{
    public class PhanSo
    {
        // 1. Fields (Tử số và mẫu số kiểu số thực - double)
        private double tuSo;
        private double mauSo;

        // 2. Constructors (Hàm khởi tạo)
        public PhanSo()
        {
            tuSo = 0;
            mauSo = 1;
        }

        public PhanSo(double tuSo, double mauSo)
        {
            TuSo = tuSo;
            MauSo = mauSo;
        }

        public PhanSo(PhanSo ps)
        {
            if (ps != null)
            {
                this.tuSo = ps.tuSo;
                this.mauSo = ps.mauSo;
            }
        }

        // 3. Properties (Thuộc tính đóng gói, kiểm tra mẫu khác 0)
        public double TuSo
        {
            get { return tuSo; }
            set { tuSo = value; }
        }

        public double MauSo
        {
            get { return mauSo; }
            set 
            { 
                // Kiểm tra số thực khác 0 an toàn bằng epsilon (1e-9)
                if (Math.Abs(value) > 1e-9)
                {
                    // Đưa dấu âm lên tử số nếu mẫu số âm
                    if (value < 0)
                    {
                        tuSo = -tuSo;
                        mauSo = -value;
                    }
                    else
                    {
                        mauSo = value;
                    }
                }
                else
                {
                    throw new ArgumentException("Mẫu số không được bằng 0!");
                }
            }
        }

        // 4. Methods nghiệp vụ (Cho phép nhập số thực)
        public void Input(string tenPhanSo)
        {
            Console.WriteLine($"--- Nhập thông tin cho phân số {tenPhanSo} (Số thực) ---");
            
            // Nhập tử số (Số thực)
            while (true)
            {
                Console.Write("Nhập tử số (số thực): ");
                if (double.TryParse(Console.ReadLine(), out double tu))
                {
                    tuSo = tu;
                    break;
                }
                Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập một số thực.");
            }

            // Nhập mẫu số (Số thực, chống mẫu = 0)
            while (true)
            {
                try
                {
                    Console.Write("Nhập mẫu số (khác 0, số thực): ");
                    if (double.TryParse(Console.ReadLine(), out double mau))
                    {
                        MauSo = mau; // Gán qua Property để tự động kiểm tra mẫu != 0
                        break;
                    }
                    else
                    {
                        Console.WriteLine("[Lỗi] Định dạng không hợp lệ! Vui lòng nhập một số thực.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Lỗi] {ex.Message} Vui lòng nhập lại.");
                }
            }
        }

        // Override ToString()
        public override string ToString()
        {
            if (Math.Abs(mauSo - 1.0) < 1e-9 || Math.Abs(tuSo) < 1e-9)
                return $"{tuSo}";
            return $"{tuSo}/{mauSo}";
        }

        // 5. Overload các toán tử (Operators Overloading)
        
        // Toán tử một ngôi
        public static PhanSo operator +(PhanSo ps)
        {
            return new PhanSo(ps.tuSo, ps.mauSo);
        }

        public static PhanSo operator -(PhanSo ps)
        {
            return new PhanSo(-ps.tuSo, ps.mauSo);
        }

        // Toán tử hai ngôi (+, -, *, /)
        public static PhanSo operator +(PhanSo ps1, PhanSo ps2)
        {
            double tu = ps1.tuSo * ps2.mauSo + ps2.tuSo * ps1.mauSo;
            double mau = ps1.mauSo * ps2.mauSo;
            return new PhanSo(tu, mau);
        }

        public static PhanSo operator -(PhanSo ps1, PhanSo ps2)
        {
            double tu = ps1.tuSo * ps2.mauSo - ps2.tuSo * ps1.mauSo;
            double mau = ps1.mauSo * ps2.mauSo;
            return new PhanSo(tu, mau);
        }

        public static PhanSo operator *(PhanSo ps1, PhanSo ps2)
        {
            double tu = ps1.tuSo * ps2.tuSo;
            double mau = ps1.mauSo * ps2.mauSo;
            return new PhanSo(tu, mau);
        }

        public static PhanSo operator /(PhanSo ps1, PhanSo ps2)
        {
            if (Math.Abs(ps2.tuSo) < 1e-9)
                throw new DivideByZeroException("Không thể chia cho phân số 0!");
            double tu = ps1.tuSo * ps2.mauSo;
            double mau = ps1.mauSo * ps2.tuSo;
            return new PhanSo(tu, mau);
        }

        // Toán tử so sánh (>, <, >=, <=, ==, !=)
        public static bool operator >(PhanSo ps1, PhanSo ps2)
        {
            return (ps1.tuSo * ps2.mauSo) > (ps2.tuSo * ps1.mauSo);
        }

        public static bool operator <(PhanSo ps1, PhanSo ps2)
        {
            return (ps1.tuSo * ps2.mauSo) < (ps2.tuSo * ps1.mauSo);
        }

        public static bool operator >=(PhanSo ps1, PhanSo ps2)
        {
            return (ps1.tuSo * ps2.mauSo) >= (ps2.tuSo * ps1.mauSo);
        }

        public static bool operator <=(PhanSo ps1, PhanSo ps2)
        {
            return (ps1.tuSo * ps2.mauSo) <= (ps2.tuSo * ps1.mauSo);
        }

        public static bool operator ==(PhanSo ps1, PhanSo ps2)
        {
            if (ReferenceEquals(ps1, ps2)) return true;
            if (ReferenceEquals(ps1, null) || ReferenceEquals(ps2, null)) return false;
            return Math.Abs(ps1.tuSo * ps2.mauSo - ps2.tuSo * ps1.mauSo) < 1e-9;
        }

        public static bool operator !=(PhanSo ps1, PhanSo ps2)
        {
            return !(ps1 == ps2);
        }

        public override bool Equals(object obj)
        {
            if (obj is PhanSo ps)
            {
                return this == ps;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(tuSo, mauSo);
        }
    }
}