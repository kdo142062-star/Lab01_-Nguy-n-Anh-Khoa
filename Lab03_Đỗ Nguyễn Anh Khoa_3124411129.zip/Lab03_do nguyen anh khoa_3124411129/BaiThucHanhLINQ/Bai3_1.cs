 using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Bai3_1
{
    public static void ChayBai3_1()
    {
        int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };

        Console.WriteLine("=== BÀI 3.1: THỐNG KÊ MẢNG SỐ ===");
        Console.WriteLine("Mảng ban đầu:");
        Console.WriteLine(string.Join(", ", mangSo));
        Console.WriteLine(new string('-', 40));

        // a. Cho biết tổng số phần tử, số phần tử chẵn và số phần tử lẻ
        int tongSoPhanTu = mangSo.Length;
        int soChan = mangSo.Count(n => n % 2 == 0);
        int soLe = mangSo.Count(n => n % 2 != 0);
        Console.WriteLine($"a. Tổng số phần tử: {tongSoPhanTu} | Số chẵn: {soChan} | Số lẻ: {soLe}");

        // b. Tính tổng các giá trị, giá trị lớn nhất và giá trị nhỏ nhất
        int tongGiaTri = mangSo.Sum();
        int maxGiaTri = mangSo.Max();
        int minGiaTri = mangSo.Min();
        Console.WriteLine($"b. Tổng giá trị: {tongGiaTri} | Lớn nhất: {maxGiaTri} | Nhỏ nhất: {minGiaTri}");

        // c. Cho biết có bao nhiêu giá trị khác nhau trong mảng
        int soGiaTriKhacNhau = mangSo.Distinct().Count();
        Console.WriteLine($"c. Số lượng giá trị khác nhau trong mảng: {soGiaTriKhacNhau}");

        // d. Phân nhóm các phần tử theo số dư khi chia cho 5
        Console.WriteLine("d. Phân nhóm các phần tử theo số dư khi chia cho 5:");
        var nhomTheoSoDu = mangSo.GroupBy(n => n % 5);
        foreach (var nhom in nhomTheoSoDu)
        {
            Console.WriteLine($"   - Số dư {nhom.Key}: {string.Join(", ", nhom)}");
        }
    }
}